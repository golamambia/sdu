(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["main"],{

/***/ 98255:
/*!*******************************************************!*\
  !*** ./$_lazy_route_resources/ lazy namespace object ***!
  \*******************************************************/
/***/ ((module) => {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(() => {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = () => ([]);
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = 98255;
module.exports = webpackEmptyAsyncContext;

/***/ }),

/***/ 70809:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 29535);



const routes = [
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    // {
    //   path: 'folder/:id',
    //   loadChildren: () => import('./folder/folder.module').then( m => m.FolderPageModule)
    // },
    {
        path: 'login',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_login_login_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./login/login.module */ 77641)).then(m => m.LoginPageModule)
    },
    {
        path: 'register',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_register_register_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./register/register.module */ 22474)).then(m => m.RegisterPageModule)
    },
    {
        path: 'profile',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_profile_profile_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./profile/profile.module */ 47350)).then(m => m.ProfilePageModule)
    },
    {
        path: 'forgot-password',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_forgot-password_forgot-password_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./forgot-password/forgot-password.module */ 31129)).then(m => m.ForgotPasswordPageModule)
    },
    {
        path: 'change-password',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_change-password_change-password_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./change-password/change-password.module */ 69976)).then(m => m.ChangePasswordPageModule)
    },
    {
        path: 'home',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_home_home_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./home/home.module */ 82711)).then(m => m.HomePageModule)
    },
    {
        path: 'attendence',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("src_app_attendence_attendence_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./attendence/attendence.module */ 64913)).then(m => m.AttendencePageModule)
    },
    {
        path: 'attendence-single',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("src_app_attendence-single_attendence-single_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./attendence-single/attendence-single.module */ 37210)).then(m => m.AttendenceSinglePageModule)
    },
    {
        path: 'attendence-single-edit',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("src_app_attendence-single-edit_attendence-single-edit_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./attendence-single-edit/attendence-single-edit.module */ 51917)).then(m => m.AttendenceSingleEditPageModule)
    },
    {
        path: 'attendence-expense',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_attendence-expense_attendence-expense_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./attendence-expense/attendence-expense.module */ 94314)).then(m => m.AttendenceExpensePageModule)
    },
    {
        path: 'attendence-expense-edit',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_lodash_lodash_js"), __webpack_require__.e("src_app_attendence-expense-edit_attendence-expense-edit_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./attendence-expense-edit/attendence-expense-edit.module */ 30409)).then(m => m.AttendenceExpenseEditPageModule)
    },
    {
        path: 'attendence-expense-add',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("default-node_modules_lodash_lodash_js"), __webpack_require__.e("src_app_attendence-expense-add_attendence-expense-add_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./attendence-expense-add/attendence-expense-add.module */ 85807)).then(m => m.AttendenceExpenseAddPageModule)
    },
    {
        path: 'attendence-b',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("src_app_attendence-b_attendence-b_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./attendence-b/attendence-b.module */ 99306)).then(m => m.AttendenceBPageModule)
    },
    {
        path: 'attendence-b-edit',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_lodash_lodash_js"), __webpack_require__.e("src_app_attendence-b-edit_attendence-b-edit_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./attendence-b-edit/attendence-b-edit.module */ 6514)).then(m => m.AttendenceBEditPageModule)
    },
    {
        path: 'attendence-b-add',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_lodash_lodash_js"), __webpack_require__.e("src_app_attendence-b-add_attendence-b-add_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./attendence-b-add/attendence-b-add.module */ 96972)).then(m => m.AttendenceBAddPageModule)
    },
    {
        path: 'attendence-b-update',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_lodash_lodash_js"), __webpack_require__.e("src_app_attendence-b-update_attendence-b-update_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./attendence-b-update/attendence-b-update.module */ 42492)).then(m => m.AttendenceBUpdatePageModule)
    },
    {
        path: 'wallet-page',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_wallet-page_wallet-page_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./wallet-page/wallet-page.module */ 70713)).then(m => m.WalletPagePageModule)
    },
    {
        path: 'return-request',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_return-request_return-request_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./return-request/return-request.module */ 67282)).then(m => m.ReturnRequestPageModule)
    },
    {
        path: 'return-request-create',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("src_app_return-request-create_return-request-create_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./return-request-create/return-request-create.module */ 54343)).then(m => m.ReturnRequestCreatePageModule)
    },
    {
        path: 'workexpense-list',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_workexpense-list_workexpense-list_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./workexpense-list/workexpense-list.module */ 67295)).then(m => m.WorkexpenseListPageModule)
    },
    {
        path: 'user-attendense-list',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_user-attendense-list_user-attendense-list_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./user-attendense-list/user-attendense-list.module */ 52746)).then(m => m.UserAttendenseListPageModule)
    },
    {
        path: 'workexpense-edit',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_lodash_lodash_js"), __webpack_require__.e("src_app_workexpense-edit_workexpense-edit_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./workexpense-edit/workexpense-edit.module */ 24329)).then(m => m.WorkexpenseEditPageModule)
    },
    {
        path: 'sallery-list',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_sallery-list_sallery-list_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./sallery-list/sallery-list.module */ 35493)).then(m => m.SalleryListPageModule)
    },
    {
        path: 'leave-page',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_leave-page_leave-page_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./leave-page/leave-page.module */ 60692)).then(m => m.LeavePagePageModule)
    },
    {
        path: 'generale-leave',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("common"), __webpack_require__.e("src_app_generale-leave_generale-leave_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./generale-leave/generale-leave.module */ 99442)).then(m => m.GeneraleLeavePageModule)
    },
    {
        path: 'medical-leave',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("common"), __webpack_require__.e("src_app_medical-leave_medical-leave_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./medical-leave/medical-leave.module */ 18690)).then(m => m.MedicalLeavePageModule)
    },
    {
        path: 'compact-leave',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("common"), __webpack_require__.e("src_app_compact-leave_compact-leave_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./compact-leave/compact-leave.module */ 89946)).then(m => m.CompactLeavePageModule)
    },
    {
        path: 'attendence-report',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_attendence-report_attendence-report_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./attendence-report/attendence-report.module */ 86850)).then(m => m.AttendenceReportPageModule)
    }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__.PreloadAllModules })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 20721:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./app.component.html */ 91106);
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss */ 43069);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../environments/environment */ 24766);
/* harmony import */ var src_app_event_events_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/event/events.service */ 1479);
/* harmony import */ var _ionic_native_battery_status_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/battery-status/ngx */ 65702);
/* harmony import */ var _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/network/ngx */ 86298);
/* harmony import */ var src_app_providers_network_util_service_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/providers/network/util-service.service */ 67032);
/* harmony import */ var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/native-geocoder/ngx */ 73181);
/* harmony import */ var _ionic_native_location_accuracy_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/location-accuracy/ngx */ 91358);
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ 71074);
/* harmony import */ var _ionic_native_android_permissions_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/android-permissions/ngx */ 68491);
/* harmony import */ var src_app_providers_watch_possition_watcher_service_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/providers/watch-possition/watcher-service.service */ 12767);
/* harmony import */ var _ionic_native_app_version_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/app-version/ngx */ 38067);
/* harmony import */ var _awesome_cordova_plugins_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @awesome-cordova-plugins/splash-screen/ngx */ 62765);























//import { UtilServiceService } from 'src/app/providers/network/util-service.service';
let AppComponent = class AppComponent {
    constructor(platform, 
    //private splashScreen: SplashScreen,
    //private statusBar: StatusBar,
    menu, navCtrl, storage, events, batteryStatus, util, network, nativeGeocoder, locationAccuracy, geolocation, androidPermissions, watcherservice, http, appVersion, splashScreen) {
        this.platform = platform;
        this.menu = menu;
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.events = events;
        this.batteryStatus = batteryStatus;
        this.util = util;
        this.network = network;
        this.nativeGeocoder = nativeGeocoder;
        this.locationAccuracy = locationAccuracy;
        this.geolocation = geolocation;
        this.androidPermissions = androidPermissions;
        this.watcherservice = watcherservice;
        this.http = http;
        this.appVersion = appVersion;
        this.splashScreen = splashScreen;
        this.isLoading = false;
        this.imag_path = _environments_environment__WEBPACK_IMPORTED_MODULE_3__.image_path;
        this.logval = _environments_environment__WEBPACK_IMPORTED_MODULE_3__.logval.production;
        this.disconnectSubscription = '';
        this.networkAlert = '';
        this.connectSubscription = '';
        this.watch = '';
        this.battery_status = '';
        this.lat = '';
        this.long = '';
        this.appversionAlert = '';
        this.st_downloadlink = '';
        this.initializeApp();
    }
    initializeApp() {
        this.platform.ready().then(() => {
            setTimeout(() => {
                //console.log(1234);
                this.checkInternetConnection();
                this.checkGpsConnection();
                this.utilService();
                this.getVersion();
            }, 6000);
            //console.log(123);
            this.getUserDetails();
            this.checkVersion();
            this.splashScreen.hide();
        });
    }
    ngOnInit() {
        // this.storage.create();
        this.events.subscribe('user:login', (data) => {
            //console.log(data);
            if (data) {
                this.getUserDetails();
            }
        });
        this.events.subscribe('user:profile', (data) => {
            //console.log(data);
            if (data) {
                this.getUserDetails();
            }
        });
    }
    checkVersion() {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_15__.HttpHeaders();
        headers.append('content-type', 'application/json; charset=utf-8');
        var data = {
            "userId": this.userId,
            //this.password
        };
        this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'get-app-version', JSON.stringify(data), { headers: headers })
            .subscribe((res) => {
            //console.log(res);
            if (res.status) {
                //console.log(res.response_data.st_appversion);
                this.getVersionNumber = res.response_data.st_appversion;
                this.st_downloadlink = res.response_data.st_downloadlink;
            }
        });
    }
    getUserDetails() {
        this.storage.create();
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                //this.userDetails = val;
                this.userId = val.ID;
                var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_15__.HttpHeaders();
                headers.append('content-type', 'application/json; charset=utf-8');
                var data = {
                    "userid": this.userId,
                    //this.password
                };
                this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'get-user-details', JSON.stringify(data), { headers: headers })
                    .subscribe((res) => {
                    //console.log(res);
                    if (res.status == true) {
                        this.userDetails = res.response_data;
                    }
                }, (err) => {
                    //console.log(err);
                });
            }
            else {
                this.navCtrl.navigateForward('login');
                this.userDetails = null;
            }
        });
    }
    getVersion() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, function* () {
            // console.log(this.getVersionNumber);
            var msgtext = '<a href="' + this.st_downloadlink + '"  > Download link </a>';
            this.appversionAlert = yield this.util.createAlert('Please update your app or download latest version!', false, msgtext, {
                text: '',
                role: '',
                cssClass: 'secondary',
                handler: () => (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, function* () { })
            });
            //this.appversionAlert.present();
            this.appVersion.getVersionNumber().then(res => {
                this.ionVersionNumber = res;
                if (res) {
                    if (this.getVersionNumber && this.ionVersionNumber) {
                        if (this.getVersionNumber != this.ionVersionNumber) {
                            this.appversionAlert.present();
                        }
                        else {
                            if (this.appversionAlert) {
                                this.appversionAlert.dismiss();
                                //this.checkUser();
                            }
                        }
                    }
                }
                //console.log(this.getVersionNumber);
                //console.log(res);
            }).catch(error => {
                // alert(error);
            });
            this.appVersion.getVersionCode().then(res => {
                this.ionVersionCode = res;
                console.log(res);
            }).catch(error => {
                // alert(error);
            });
        });
    }
    logout() {
        this.storage.remove("genuserDetails");
        //this.storage.set("checkin",0);
        //.then(() => { this.events.publish('user:login', false) });
        this.userDetails = null;
        this.navCtrl.navigateForward('login');
        this.menu.close();
        //this.events.publish('user:logout', true);
    }
    close() {
        this.menu.close();
    }
    checkInternetConnection() {
        //console.log(123);
        this.disconnectSubscription = this.network.onDisconnect().subscribe(() => (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, function* () {
            // console.log('network was disconnected :-(');
            this.networkAlert = yield this.util.createAlert('No Internet', false, 'Please Check you internet Connection and try again', {
                text: '',
                role: '',
                cssClass: 'secondary',
                handler: () => (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, function* () { })
            });
            //alert('Please Check you internet Connection and try again');
            this.networkAlert.present();
        }));
        this.connectSubscription = this.network.onConnect().subscribe(() => {
            // console.log('network connected!');
            if (this.networkAlert) {
                this.networkAlert.dismiss();
                //this.checkUser();
            }
        });
    }
    checkGpsConnection() {
        this.watch = this.geolocation.watchPosition();
        this.watch.subscribe((data) => {
            // usable data
            //console.log(data.coords);
            this.lat = data.coords.latitude;
            this.long = data.coords.longitude;
            //alert(1+data)
        }, (error) => {
            // alert(error)
            // some error
        }, { timeout: 30000 });
    }
    ngOnDestroy() {
        this.watch.unsubscribe();
    }
    utilService() {
        //console.log(123);
        setInterval(() => 
        //console.log('done') 
        this.statusPost(), 300000);
    }
    statusPost() {
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                this.userDetails = val;
                this.userId = val.ID;
                //console.log(val);
            }
        });
        this.watch = this.geolocation.watchPosition();
        this.watch.subscribe((data) => {
            // usable data
            // console.log(data);
            this.lat = data.coords.latitude;
            this.long = data.coords.longitude;
            //alert(1+data)300000
        });
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_15__.HttpHeaders();
        headers.append('content-type', 'application/json; charset=utf-8');
        //console.log('done') ;
        this.batteryStatus.onChange().subscribe(status => {
            console.log('batteryStatus', status.level);
            this.battery_status = status.level;
        });
        var data = {
            "userId": this.userId,
            "battery_status": this.battery_status,
            "lat": this.lat,
            "long": this.long,
            //this.password
        };
        this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'device-status-post', JSON.stringify(data), { headers: headers })
            .subscribe((res) => {
            //console.log(res);
        });
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.Platform },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.MenuController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: src_app_event_events_service__WEBPACK_IMPORTED_MODULE_4__.Events },
    { type: _ionic_native_battery_status_ngx__WEBPACK_IMPORTED_MODULE_5__.BatteryStatus },
    { type: src_app_providers_network_util_service_service__WEBPACK_IMPORTED_MODULE_7__.UtilServiceService },
    { type: _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_6__.Network },
    { type: _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_8__.NativeGeocoder },
    { type: _ionic_native_location_accuracy_ngx__WEBPACK_IMPORTED_MODULE_9__.LocationAccuracy },
    { type: _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_10__.Geolocation },
    { type: _ionic_native_android_permissions_ngx__WEBPACK_IMPORTED_MODULE_11__.AndroidPermissions },
    { type: src_app_providers_watch_possition_watcher_service_service__WEBPACK_IMPORTED_MODULE_12__.WatcherServiceService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_15__.HttpClient },
    { type: _ionic_native_app_version_ngx__WEBPACK_IMPORTED_MODULE_13__.AppVersion },
    { type: _awesome_cordova_plugins_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_14__.SplashScreen }
];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_18__.Component)({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AppComponent);



/***/ }),

/***/ 50023:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/platform-browser */ 93220);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component */ 20721);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app-routing.module */ 70809);
/* harmony import */ var _event_events_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./event/events.service */ 1479);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_native_location_accuracy_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/location-accuracy/ngx */ 91358);
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ 71074);
/* harmony import */ var _ionic_native_android_permissions_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/android-permissions/ngx */ 68491);
/* harmony import */ var _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/native-geocoder/ngx */ 73181);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/camera/ngx */ 45103);
/* harmony import */ var _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/photo-viewer/ngx */ 41765);
/* harmony import */ var _ionic_native_base64_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/base64/ngx */ 43170);
/* harmony import */ var _ionic_native_battery_status_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/battery-status/ngx */ 65702);
/* harmony import */ var _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/network/ngx */ 86298);
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/file/ngx */ 5901);
/* harmony import */ var _ionic_native_app_version_ngx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic-native/app-version/ngx */ 38067);
/* harmony import */ var _awesome_cordova_plugins_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @awesome-cordova-plugins/splash-screen/ngx */ 62765);



// import { IonicStorageModule } from '@ionic/storage-angular';
//import { IonicStorageModule } from '@ionic/storage';



//import { HttpModule } from '@angular/http';


















let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_17__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_18__.BrowserModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonicModule.forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_2__.AppRoutingModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_20__.HttpClientModule,
            //IonicStorageModule.forRoot(), 
            _angular_forms__WEBPACK_IMPORTED_MODULE_21__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_21__.ReactiveFormsModule,
        ],
        providers: [
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_22__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonicRouteStrategy },
            _event_events_service__WEBPACK_IMPORTED_MODULE_3__.Events, _ionic_native_native_geocoder_ngx__WEBPACK_IMPORTED_MODULE_7__.NativeGeocoder, _ionic_storage__WEBPACK_IMPORTED_MODULE_0__.Storage, _angular_common__WEBPACK_IMPORTED_MODULE_23__.DatePipe, _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_8__.Camera, _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_9__.PhotoViewer, _ionic_native_base64_ngx__WEBPACK_IMPORTED_MODULE_10__.Base64, _ionic_native_location_accuracy_ngx__WEBPACK_IMPORTED_MODULE_4__.LocationAccuracy,
            _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_5__.Geolocation, _ionic_native_battery_status_ngx__WEBPACK_IMPORTED_MODULE_11__.BatteryStatus, _ionic_native_network_ngx__WEBPACK_IMPORTED_MODULE_12__.Network, _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_13__.File, _awesome_cordova_plugins_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_15__.SplashScreen,
            _ionic_native_android_permissions_ngx__WEBPACK_IMPORTED_MODULE_6__.AndroidPermissions, _ionic_native_app_version_ngx__WEBPACK_IMPORTED_MODULE_14__.AppVersion
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 1479:
/*!*****************************************!*\
  !*** ./src/app/event/events.service.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Events": () => (/* binding */ Events)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 6006);



let Events = class Events {
    constructor() {
        this.channels = {};
    }
    subscribe(topic, observer) {
        if (!this.channels[topic]) {
            this.channels[topic] = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
        }
        return this.channels[topic].subscribe(observer);
    }
    publish(topic, data) {
        const subject = this.channels[topic];
        if (!subject) {
            return;
        }
        subject.next(data);
    }
    destroy(topic) {
        const subject = this.channels[topic];
        if (!subject) {
            return;
        }
        subject.complete();
        delete this.channels[topic];
    }
};
Events = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], Events);



/***/ }),

/***/ 67032:
/*!***********************************************************!*\
  !*** ./src/app/providers/network/util-service.service.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UtilServiceService": () => (/* binding */ UtilServiceService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 34595);



let UtilServiceService = class UtilServiceService {
    constructor(alertCtrl) {
        this.alertCtrl = alertCtrl;
    }
    createAlert(header, backdropDismiss, message, buttonOptions1, buttonOptions2) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header,
                backdropDismiss,
                message,
                buttons: !buttonOptions2 ? [buttonOptions1] : [buttonOptions1, buttonOptions2]
            });
            return alert;
        });
    }
};
UtilServiceService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.AlertController }
];
UtilServiceService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], UtilServiceService);



/***/ }),

/***/ 12767:
/*!**********************************************************************!*\
  !*** ./src/app/providers/watch-possition/watcher-service.service.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WatcherServiceService": () => (/* binding */ WatcherServiceService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 42741);


let WatcherServiceService = class WatcherServiceService {
    constructor() { }
};
WatcherServiceService.ctorParameters = () => [];
WatcherServiceService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    })
], WatcherServiceService);



/***/ }),

/***/ 24766:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment),
/* harmony export */   "host": () => (/* binding */ host),
/* harmony export */   "image_path": () => (/* binding */ image_path),
/* harmony export */   "logval": () => (/* binding */ logval)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
const host = 'https://consult-trico.com/erpstagging/api/';
const image_path = 'https://consult-trico.com/erpstagging/';
const logval = {
    production: 'not'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 8835:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 90476);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 50023);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 24766);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 50863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-action-sheet.entry.js": [
		95261,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		26,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		29009,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		27221,
		"common",
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		34694,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		70993,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-button_2.entry.js": [
		63645,
		"common",
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		62245,
		"common",
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		23482,
		"common",
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		4081,
		"common",
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		53315,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		64133,
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		37542,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		21459,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		47618,
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		90101,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		82210,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		47370,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		23652,
		"common",
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		28220,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		25500,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		84913,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-popover.entry.js": [
		15078,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		14857,
		"common",
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		48958,
		"common",
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		14383,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		97630,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		81297,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		35492,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		13752,
		"common",
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		7487,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		61778,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		82904,
		"common",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		81609,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		31218,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		92849,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		4127,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		28400,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		14397,
		"common",
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		43391,
		"common",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		66793,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		11695,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		4180,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 50863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 43069:
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("@import url(\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css\");\n@import url(\"https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css\");\n@import url(\"https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap\");\nion-icon {\n  color: #071662;\n}\nion-label {\n  font-size: 17px !important;\n  font-weight: bold;\n  font-family: \"Inter Regular\" !important;\n}\nhtml,\nbody {\n  display: block;\n  height: 100%;\n  margin: 0;\n  font-family: \"Raleway\", sans-serif;\n  position: relative;\n  z-index: 1;\n  background-color: #ffffff;\n}\n*,\n::after,\n::before {\n  box-sizing: border-box;\n}\nh1,\nh2,\nh3,\nh4,\nh5,\nh6 {\n  font-family: \"Raleway\", sans-serif;\n}\nh3.h3 {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 0 0;\n  margin: 0 0 15px;\n  color: #000000;\n  font-size: 16px;\n  font-weight: 700;\n  text-transform: capitalize;\n}\nh3.h3 .view_link {\n  float: right;\n  border: none;\n  outline: none;\n  color: #099fea;\n  font-size: 12px;\n  background: transparent;\n}\nimg {\n  max-width: 100%;\n  height: auto;\n}\n.justify-content-between {\n  justify-content: space-between !important;\n}\n.d-flex {\n  display: flex !important;\n}\n.container {\n  box-sizing: border-box;\n  padding: 0px 30px;\n  width: 100%;\n}\n.w-100 {\n  width: 100%;\n  box-sizing: border-box;\n}\n.body_warrper {\n  width: 100%;\n  height: 100vh;\n  box-sizing: border-box;\n  padding: 0 0 0;\n  position: relative;\n}\n.header_area {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 30px 0;\n  margin: 0 0 0;\n  text-align: center;\n  position: fixed;\n  left: 0;\n  top: 0;\n  z-index: 9;\n  position: relative;\n}\n.btn-nav {\n  float: left;\n  background: transparent;\n  border: none;\n  outline: none;\n  padding: 0 0;\n}\n.header_area .search_area {\n  position: absolute;\n  top: 28%;\n  right: 4%;\n  width: 78%;\n}\n.body_area {\n  width: 100%;\n  box-sizing: border-box;\n}\n.platform_main_area {\n  content: \"\";\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  width: 100%;\n  background: #fff;\n  padding: 0px 0px 30px;\n  box-sizing: border-box;\n  height: 56%;\n  overflow-y: scroll;\n  padding-top: 5px;\n}\n.main_body_area {\n  width: 100%;\n  box-sizing: border-box;\n  position: relative;\n}\n.banner_area {\n  width: 100%;\n  box-sizing: border-box;\n  position: fixed;\n  top: 0;\n  left: 0;\n}\n.banner_area .banner {\n  width: 100%;\n  height: 290px;\n  box-sizing: border-box;\n  background-size: cover;\n  background-position: center;\n  background-repeat: no-repeat;\n  background-image: url('banner1.jpg');\n  position: relative;\n  overflow: hidden;\n}\n.banner_area .banner:before {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  background-image: url('sape7.jpg');\n  background-size: 100%;\n  background-position: center;\n  background-repeat: no-repeat;\n  mix-blend-mode: screen;\n}\n.banner_area .banner .banner_contain {\n  position: absolute;\n  top: 24%;\n  left: 8%;\n  width: 50%;\n}\n.banner_area .banner .banner_contain h1 {\n  width: 100%;\n  line-height: normal;\n  color: #ffffff;\n  font-size: 24px;\n  font-weight: 500;\n  box-sizing: border-box;\n  padding: 0 0;\n  margin: 0 0;\n}\n.banner_area .banner .banner_contain h1 strong {\n  display: block;\n  color: #099fea;\n  font-weight: 500;\n}\n.search_area {\n  width: 100%;\n  box-sizing: border-box;\n  margin-bottom: 20px;\n}\n.search_area .search {\n  width: 100%;\n  box-sizing: border-box;\n  position: relative;\n}\n.form-control {\n  width: 100%;\n  height: 38px;\n  box-sizing: border-box;\n  padding: 10px 65px 10px 10px;\n  border: 1px solid #dadada;\n  box-shadow: 0 0 5px rgba(228, 228, 228, 0.76);\n  border-radius: 30px;\n  outline: none;\n  background: rgba(226, 226, 226, 0.32);\n}\n.search_area .search .btn-search {\n  content: \"\";\n  position: absolute;\n  bottom: 3px;\n  right: 3px;\n  background: #86be41;\n  border: 1px solid #86be41;\n  box-sizing: border-box;\n  border-radius: 30px;\n  padding: 4px 14px;\n  color: #fff;\n  font-size: 18px;\n  font-weight: 600;\n  outline: none;\n}\n.category_main_area {\n  overflow: hidden;\n  margin-bottom: 20px;\n}\n.category_main_area .category_listing {\n  overflow: scroll;\n  box-sizing: border-box;\n}\n.category_main_area .category_listing ul {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n  display: table;\n  width: 100%;\n}\n.category_main_area .category_listing ul li {\n  display: table-cell;\n  vertical-align: top;\n  list-style: none;\n}\n.category_box {\n  width: 110px;\n  height: 81px;\n  padding: 10px 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  box-sizing: border-box;\n  border-radius: 10px;\n  overflow: hidden;\n  text-align: center;\n  margin-right: 8px;\n}\n.category_box h4 {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 4px 0 0;\n  margin: 0 0 0;\n  color: #000000;\n  font-size: 13px;\n  font-weight: 600;\n}\n.category_box.bg1 {\n  background: #ebffd2;\n}\n.category_box.bg2 {\n  background: #cbedff;\n}\n.category_box.bg3 {\n  background: #e1e1e1;\n}\n.category_box.bg4 {\n  background: #fee0e0;\n}\nul.course_listing {\n  width: 100%;\n  padding: 0 0;\n  margin: 0 0;\n}\nul.course_listing li {\n  width: 48%;\n  float: left;\n  list-style: none;\n  margin: 0 8px 12px 0;\n  padding: 0 0;\n}\nul.course_listing li:nth-of-type(2n) {\n  width: 49%;\n  float: right;\n  margin: 0 0 0 0;\n}\n.course_box {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 0 0;\n  margin: 0 0;\n}\n.course_box .img_box {\n  width: 100%;\n  height: 126px;\n  overflow: hidden;\n  box-sizing: border-box;\n  margin: 0 0 10px;\n  border-radius: 10px;\n}\n.course_box .img_box img {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.course_box h3 {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 0 0 0;\n  margin: 0 0 3px;\n  color: #000000;\n  font-size: 15px;\n  font-weight: 600;\n}\n.course_box p {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 0 0 0;\n  margin: 0 0 5px;\n  color: #000000;\n  font-size: 13px;\n  font-weight: 500;\n}\n.course_box .btn {\n  padding: 0 0 0;\n  margin: 0 0 0;\n  color: #1ca3ed;\n  font-size: 14px;\n  font-weight: 500;\n  background: transparent;\n  border: none;\n  outline: none;\n  display: inline-block;\n  text-transform: uppercase;\n}\n.about_area {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 20px 0px;\n}\n.about_area ul {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 0 0;\n  margin: 0 0;\n  list-style: none;\n  display: table;\n}\n.about_area ul li {\n  width: 50%;\n  display: table-cell;\n  vertical-align: top;\n  padding: 0 0;\n  margin: 0 0;\n}\n.about_area .about_img_box {\n  width: 100%;\n  height: 154px;\n  overflow: hidden;\n  border-radius: 5px;\n}\n.about_area .about_img_box img {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.about_area .about_contain_box {\n  text-align: center;\n  width: 100%;\n  box-sizing: border-box;\n  padding: 10px 10px;\n}\n.about_area .about_contain_box h3 {\n  width: 100%;\n  line-height: normal;\n  font-size: 17px;\n  font-weight: 600;\n  color: #000000;\n  margin: 0 0 8px;\n}\n.about_area .about_contain_box p {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 0 0;\n  margin: 0 0;\n  color: #000000;\n  font-size: 13px;\n  font-weight: 300;\n}\n.services_area {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 0 0 0;\n  margin: 0 0 0;\n}\n.services_area h2 {\n  width: 100%;\n  line-height: normal;\n  box-sizing: border-box;\n  font-size: 17px;\n  font-weight: 600;\n  color: #000000;\n  margin: 0 0 10px;\n}\n.services_area .service_box {\n  width: 100%;\n  height: 170px;\n  box-sizing: border-box;\n  position: relative;\n  overflow: hidden;\n  border-radius: 10px;\n  margin-bottom: 15px;\n}\n.services_area .service_box img {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n  position: relative;\n  z-index: 0;\n}\n.services_area .service_box .contain_box {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  z-index: 1;\n  width: 100%;\n  padding: 15px 15px;\n  box-sizing: border-box;\n}\n.services_area .service_box .contain_box h3 {\n  width: 100%;\n  box-sizing: border-box;\n  line-height: normal;\n  margin: 0 0 5px;\n  padding: 0 0;\n  color: #ffffff;\n  text-transform: uppercase;\n  font-size: 17px;\n  font-weight: 600;\n}\n.services_area .service_box .contain_box p {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 0 0;\n  margin: 0 0;\n  color: #ffffff;\n  font-size: 13px;\n  font-weight: 400;\n  line-height: 20px;\n}\n.top_collage_box {\n  width: 290px;\n  min-height: 102px;\n  box-sizing: border-box;\n  position: relative;\n  padding-left: 125px;\n}\n.top_collage_box .img_box {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 118px;\n  height: 102px;\n  overflow: hidden;\n  box-sizing: border-box;\n  border-radius: 5px;\n}\n.top_collage_box .img_box img {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.top_collage_box .link {\n  outline: none;\n  width: 100%;\n  box-sizing: border-box;\n  color: #000000;\n  font-size: 13px;\n  border: none;\n  text-align: left;\n  font-weight: 500;\n  margin: 0 0 10px;\n}\n.top_collage_box p {\n  width: 100%;\n  line-height: normal;\n  box-sizing: border-box;\n  margin: 0 0;\n  padding: 0 0;\n  color: #1781ba;\n  font-size: 15px;\n}\n.courses_box {\n  width: 100%;\n  min-height: 100px;\n  box-sizing: border-box;\n  position: relative;\n  padding-left: 110px;\n  padding-top: 5px;\n  margin-bottom: 15px;\n}\n.courses_box .img_box {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100px;\n  height: 100px;\n  box-sizing: border-box;\n  border-radius: 10px;\n  overflow: hidden;\n}\n.courses_box .img_box img {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.courses_box h3 {\n  width: 100%;\n  box-sizing: border-box;\n  margin: 0 0 5px;\n  color: #031826;\n  font-size: 17px;\n  font-weight: 600;\n  text-transform: uppercase;\n}\n.courses_box h3 strong {\n  display: block;\n  box-sizing: border-box;\n  color: #1097da;\n  font-size: 13px;\n  font-weight: 600;\n}\n.courses_box p {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 0 0 0;\n  margin: 0 0 5px;\n  color: #767676;\n  font-size: 13px;\n}\n.courses_box .btn_link {\n  border: none;\n  outline: none;\n  color: #099fea;\n  font-size: 12px;\n  background: transparent;\n  padding: 0 0;\n}\n.w-285 {\n  width: 285px;\n}\n.our_partner_area {\n  width: 100%;\n  box-sizing: border-box;\n  position: relative;\n  padding: 152px 0px 40px;\n  margin-top: -70px;\n}\n.our_partner_area:after {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 290px;\n  background-position: center;\n  background-size: cover;\n  background-repeat: no-repeat;\n  background-image: url('sape8.png');\n}\n.our_partner_area h3 {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 0 0;\n  margin: 0 0 15px;\n  color: #ffffff;\n  font-size: 16px;\n  font-weight: 700;\n  text-transform: capitalize;\n  position: relative;\n  z-index: 1;\n}\n.our_partner_area .partner_carasal {\n  width: 100%;\n  box-sizing: border-box;\n  position: relative;\n  z-index: 1;\n}\n.partner_box {\n  width: 100%;\n  height: 62px;\n  margin: 0 8px 0 0;\n  overflow: hidden;\n  border-radius: 10px;\n}\n.partner_box:last-child {\n  margin: 0 0 0 0;\n}\n.partner_box img {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.partner_carasal .partner_nav {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 10px 0px 0px;\n  text-align: center;\n}\n.partner_carasal .partner_nav .btn {\n  display: inline-block;\n  outline: none;\n  width: 10px;\n  height: 10px;\n  box-sizing: border-box;\n  border: 1px solid #ffffff;\n  background: transparent;\n  cursor: pointer;\n  border-radius: 50%;\n  padding: 0 0;\n}\n.partner_carasal .partner_nav .btn.active {\n  background: #ffffff;\n}\n/*------- menu css start -------*/\n.menu_area {\n  content: \"\";\n  position: fixed;\n  top: 0;\n  left: 0;\n  width: 100%;\n}\n.menu_area .menu_profile {\n  width: 100%;\n  height: 271px;\n  box-sizing: border-box;\n  /*background-image: url(../assets/images/menu-bg.jpg);*/\n  background-color: #071662;\n  background-repeat: no-repeat;\n  background-size: cover;\n  background-position: center;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 25px 25px;\n  text-align: center;\n}\n.menu_area .menu_profile .menu_img {\n  width: 120px;\n  height: 120px;\n  overflow: hidden;\n  border: 2px dashed #a6d07e;\n  box-sizing: border-box;\n  border-radius: 50%;\n  margin-bottom: 10px;\n  margin: 0 auto 15px;\n  padding: 3px;\n}\n.menu_area .menu_profile .menu_img img {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n  border-radius: 50%;\n  box-sizing: border-box;\n}\n.menu_area .menu_profile h1 {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 0 0;\n  margin: 0 0 5px;\n  font-size: 18px;\n  font-weight: 500;\n  color: #fff;\n  text-transform: capitalize;\n  font-family: \"Inter Regular\";\n}\n.menu_area .menu_profile p {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 0 0;\n  margin: 0 0 0;\n  font-size: 15px;\n  font-weight: 300;\n  color: #fff;\n  text-transform: capitalize;\n}\n.menu_area .menu_profile h2 {\n  display: inline-block;\n  padding: 8px 20px;\n  font-size: 15px;\n  font-weight: 600;\n  background: #fff;\n  box-sizing: border-box;\n  border-radius: 30px;\n}\n.menu_area .menu_profile h2 strong {\n  display: inline-block;\n  color: #8dc63f;\n}\n.menu_nav_area {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 25px 25px;\n  overflow: auto;\n  height: 100vh;\n}\n.menu_nav_area ul {\n  width: 100%;\n  padding: 0 0;\n  margin: 0 0;\n  overflow: auto;\n  min-height: 400px;\n}\n.menu_nav_area ul li {\n  padding: 0 0;\n  margin: 0 0 30px;\n  list-style: none;\n}\n.menu_nav_area ul li .menu_nav {\n  color: #000;\n  font-size: 18px;\n  font-weight: 400;\n  text-transform: capitalize;\n  letter-spacing: 1px;\n}\n.menu_nav_area ul li .menu_nav i {\n  color: #1ca3ed;\n}\n/*------- menu css stop -------*/\n.app-version {\n  margin-top: -6px;\n  font-size: 11px;\n  color: #071662;\n  font-family: \"Inter Medium\";\n  font-weight: 600;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBUSx5RkFBQTtBQUNBLCtIQUFBO0FBQ0Esa01BQUE7QUFDUjtFQUNFLGNBQUE7QUFDRjtBQUNBO0VBQ0UsMEJBQUE7RUFDQSxpQkFBQTtFQUNBLHVDQUFBO0FBRUY7QUFBQTs7RUFFRSxjQUFBO0VBQ0EsWUFBQTtFQUNBLFNBQUE7RUFDQSxrQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLHlCQUFBO0FBR0Y7QUFEQTs7O0VBR0Usc0JBQUE7QUFJRjtBQUZBOzs7Ozs7RUFNRSxrQ0FBQTtBQUtGO0FBSEE7RUFDRSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsMEJBQUE7QUFNRjtBQUpBO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSx1QkFBQTtBQU9GO0FBTEE7RUFDRSxlQUFBO0VBQ0EsWUFBQTtBQVFGO0FBTkE7RUFFRSx5Q0FBQTtBQVNGO0FBUEE7RUFFRSx3QkFBQTtBQVVGO0FBUkE7RUFDRSxzQkFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtBQVdGO0FBVEE7RUFDRSxXQUFBO0VBQ0Esc0JBQUE7QUFZRjtBQVZBO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQWFGO0FBWEE7RUFDRSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxlQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLE9BQUE7RUFDQSxNQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0FBY0Y7QUFaQTtFQUNFLFdBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtBQWVGO0FBYkE7RUFDRSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtBQWdCRjtBQWRBO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0FBaUJGO0FBZEE7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0VBQ0Esc0JBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQWlCRjtBQWZBO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7QUFrQkY7QUFoQkE7RUFDRSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxlQUFBO0VBQ0EsTUFBQTtFQUNBLE9BQUE7QUFtQkY7QUFqQkE7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0Esc0JBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0VBQ0Esb0NBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FBb0JGO0FBbEJBO0VBQ0UsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsTUFBQTtFQUNBLE9BQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtDQUFBO0VBQ0EscUJBQUE7RUFDQSwyQkFBQTtFQUNBLDRCQUFBO0VBQ0Esc0JBQUE7QUFxQkY7QUFuQkE7RUFDRSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxRQUFBO0VBQ0EsVUFBQTtBQXNCRjtBQXBCQTtFQUNFLFdBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FBdUJGO0FBckJBO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQXdCRjtBQXRCQTtFQUNFLFdBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0FBeUJGO0FBdkJBO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7QUEwQkY7QUF4QkE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHNCQUFBO0VBQ0EsNEJBQUE7RUFDQSx5QkFBQTtFQUNBLDZDQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EscUNBQUE7QUEyQkY7QUF6QkE7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtBQTRCRjtBQTFCQTtFQUNFLGdCQUFBO0VBQ0EsbUJBQUE7QUE2QkY7QUEzQkE7RUFDRSxnQkFBQTtFQUNBLHNCQUFBO0FBOEJGO0FBNUJBO0VBQ0UsU0FBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxXQUFBO0FBK0JGO0FBN0JBO0VBQ0UsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBZ0NGO0FBOUJBO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQWlDRjtBQS9CQTtFQUNFLFdBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUFrQ0Y7QUFoQ0E7RUFDRSxtQkFBQTtBQW1DRjtBQWpDQTtFQUNFLG1CQUFBO0FBb0NGO0FBbENBO0VBQ0UsbUJBQUE7QUFxQ0Y7QUFuQ0E7RUFDRSxtQkFBQTtBQXNDRjtBQXBDQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQXVDRjtBQXJDQTtFQUNFLFVBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFBQTtFQUNBLFlBQUE7QUF3Q0Y7QUF0Q0E7RUFDRSxVQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUF5Q0Y7QUF2Q0E7RUFDRSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQTBDRjtBQXhDQTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUEyQ0Y7QUF6Q0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FBNENGO0FBMUNBO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBNkNGO0FBM0NBO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBOENGO0FBNUNBO0VBQ0UsY0FBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLHFCQUFBO0VBQ0EseUJBQUE7QUErQ0Y7QUE1Q0E7RUFDRSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxpQkFBQTtBQStDRjtBQTdDQTtFQUNFLFdBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FBZ0RGO0FBOUNBO0VBQ0UsVUFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQWlERjtBQS9DQTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQWtERjtBQWhEQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUFtREY7QUFqREE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0FBb0RGO0FBbERBO0VBQ0UsV0FBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7QUFxREY7QUFuREE7RUFDRSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUFzREY7QUFuREE7RUFDRSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtBQXNERjtBQXBEQTtFQUNFLFdBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FBdURGO0FBckRBO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0FBd0RGO0FBdERBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtBQXlERjtBQXZEQTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLE9BQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7QUEwREY7QUF4REE7RUFDRSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLHlCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBMkRGO0FBekRBO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUE0REY7QUExREE7RUFDRSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUE2REY7QUEzREE7RUFDRSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7QUE4REY7QUE1REE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FBK0RGO0FBN0RBO0VBQ0UsYUFBQTtFQUNBLFdBQUE7RUFDQSxzQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQWdFRjtBQTlEQTtFQUNFLFdBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQWlFRjtBQS9EQTtFQUNFLFdBQUE7RUFDQSxpQkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUFrRUY7QUFoRUE7RUFDRSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUFtRUY7QUFqRUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FBb0VGO0FBbEVBO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5QkFBQTtBQXFFRjtBQW5FQTtFQUNFLGNBQUE7RUFDQSxzQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUFzRUY7QUFwRUE7RUFDRSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FBdUVGO0FBckVBO0VBQ0UsWUFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLHVCQUFBO0VBQ0EsWUFBQTtBQXdFRjtBQXRFQTtFQUNFLFlBQUE7QUF5RUY7QUF2RUE7RUFDRSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0EsaUJBQUE7QUEwRUY7QUF4RUE7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EsMkJBQUE7RUFDQSxzQkFBQTtFQUNBLDRCQUFBO0VBQ0Esa0NBQUE7QUEyRUY7QUF6RUE7RUFDRSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7QUE0RUY7QUExRUE7RUFDRSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7QUE2RUY7QUEzRUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQThFRjtBQTVFQTtFQUNFLGVBQUE7QUErRUY7QUE3RUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FBZ0ZGO0FBOUVBO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtBQWlGRjtBQS9FQTtFQUNFLHFCQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSx5QkFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtBQWtGRjtBQWhGQTtFQUNFLG1CQUFBO0FBbUZGO0FBaEZBLGlDQUFBO0FBQ0E7RUFDRSxXQUFBO0VBQ0EsZUFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsV0FBQTtBQW1GRjtBQWpGQTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx1REFBQTtFQUNBLHlCQUFBO0VBQ0EsNEJBQUE7RUFDQSxzQkFBQTtFQUNBLDJCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBb0ZGO0FBbEZBO0VBQ0UsWUFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtFQUNBLDBCQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0FBcUZGO0FBbkZBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7QUFzRkY7QUFwRkE7RUFDRSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLFdBQUE7RUFDQSwwQkFBQTtFQUNBLDRCQUFBO0FBdUZGO0FBckZBO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0VBQ0EsMEJBQUE7QUF3RkY7QUF0RkE7RUFDRSxxQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0FBeUZGO0FBdkZBO0VBQ0UscUJBQUE7RUFDQSxjQUFBO0FBMEZGO0FBdkZBO0VBQ0UsV0FBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtBQTBGRjtBQXhGQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQTJGRjtBQXpGQTtFQUNFLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0FBNEZGO0FBMUZBO0VBQ0UsV0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLDBCQUFBO0VBQ0EsbUJBQUE7QUE2RkY7QUEzRkE7RUFDRSxjQUFBO0FBOEZGO0FBNUZBLGdDQUFBO0FBQ0E7RUFDRSxnQkFBQTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0EsMkJBQUE7RUFDQSxnQkFBQTtBQStGSiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAaW1wb3J0IHVybChcImh0dHBzOi8vY2RuanMuY2xvdWRmbGFyZS5jb20vYWpheC9saWJzL2ZvbnQtYXdlc29tZS81LjE0LjAvY3NzL2FsbC5taW4uY3NzXCIpO1xuQGltcG9ydCB1cmwoXCJodHRwczovL2NkbmpzLmNsb3VkZmxhcmUuY29tL2FqYXgvbGlicy9tYXRlcmlhbC1kZXNpZ24taWNvbmljLWZvbnQvMi4yLjAvY3NzL21hdGVyaWFsLWRlc2lnbi1pY29uaWMtZm9udC5taW4uY3NzXCIpO1xuQGltcG9ydCB1cmwoXCJodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2NzczI/ZmFtaWx5PVJhbGV3YXk6aXRhbCx3Z2h0QDAsMTAwOzAsMjAwOzAsMzAwOzAsNDAwOzAsNTAwOzAsNjAwOzAsNzAwOzAsODAwOzAsOTAwOzEsMTAwOzEsMjAwOzEsMzAwOzEsNDAwOzEsNTAwOzEsNjAwOzEsNzAwOzEsODAwOzEsOTAwJmRpc3BsYXk9c3dhcFwiKTtcbmlvbi1pY29uIHtcbiAgY29sb3I6ICMwNzE2NjI7XG59XG5pb24tbGFiZWwge1xuICBmb250LXNpemU6IDE3cHggIWltcG9ydGFudDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGZvbnQtZmFtaWx5OiBcIkludGVyIFJlZ3VsYXJcIiAhaW1wb3J0YW50O1xufVxuaHRtbCxcbmJvZHkge1xuICBkaXNwbGF5OiBibG9jaztcbiAgaGVpZ2h0OiAxMDAlO1xuICBtYXJnaW46IDA7XG4gIGZvbnQtZmFtaWx5OiBcIlJhbGV3YXlcIiwgc2Fucy1zZXJpZjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB6LWluZGV4OiAxO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xufVxuKixcbjo6YWZ0ZXIsXG46OmJlZm9yZSB7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG59XG5oMSxcbmgyLFxuaDMsXG5oNCxcbmg1LFxuaDYge1xuICBmb250LWZhbWlseTogXCJSYWxld2F5XCIsIHNhbnMtc2VyaWY7XG59XG5oMy5oMyB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBwYWRkaW5nOiAwIDA7XG4gIG1hcmdpbjogMCAwIDE1cHg7XG4gIGNvbG9yOiAjMDAwMDAwO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xufVxuaDMuaDMgLnZpZXdfbGluayB7XG4gIGZsb2F0OiByaWdodDtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xuICBjb2xvcjogIzA5OWZlYTtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cbmltZyB7XG4gIG1heC13aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiBhdXRvO1xufVxuLmp1c3RpZnktY29udGVudC1iZXR3ZWVuIHtcbiAgLW1zLWZsZXgtcGFjazoganVzdGlmeSAhaW1wb3J0YW50O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW4gIWltcG9ydGFudDtcbn1cbi5kLWZsZXgge1xuICBkaXNwbGF5OiAtbXMtZmxleGJveCAhaW1wb3J0YW50O1xuICBkaXNwbGF5OiBmbGV4ICFpbXBvcnRhbnQ7XG59XG4uY29udGFpbmVyIHtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgcGFkZGluZzogMHB4IDMwcHg7XG4gIHdpZHRoOiAxMDAlO1xufVxuLnctMTAwIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG59XG4uYm9keV93YXJycGVyIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwdmg7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIHBhZGRpbmc6IDAgMCAwO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4uaGVhZGVyX2FyZWEge1xuICB3aWR0aDogMTAwJTtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgcGFkZGluZzogMzBweCAwO1xuICBtYXJnaW46IDAgMCAwO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgbGVmdDogMDtcbiAgdG9wOiAwO1xuICB6LWluZGV4OiA5O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4uYnRuLW5hdiB7XG4gIGZsb2F0OiBsZWZ0O1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgYm9yZGVyOiBub25lO1xuICBvdXRsaW5lOiBub25lO1xuICBwYWRkaW5nOiAwIDA7XG59XG4uaGVhZGVyX2FyZWEgLnNlYXJjaF9hcmVhIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDI4JTtcbiAgcmlnaHQ6IDQlO1xuICB3aWR0aDogNzglO1xufVxuLmJvZHlfYXJlYSB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xufVxuXG4ucGxhdGZvcm1fbWFpbl9hcmVhIHtcbiAgY29udGVudDogXCJcIjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDA7XG4gIGxlZnQ6IDA7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICBwYWRkaW5nOiAwcHggMHB4IDMwcHg7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIGhlaWdodDogNTYlO1xuICBvdmVyZmxvdy15OiBzY3JvbGw7XG4gIHBhZGRpbmctdG9wOiA1cHg7XG59XG4ubWFpbl9ib2R5X2FyZWEge1xuICB3aWR0aDogMTAwJTtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLmJhbm5lcl9hcmVhIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgdG9wOiAwO1xuICBsZWZ0OiAwO1xufVxuLmJhbm5lcl9hcmVhIC5iYW5uZXIge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAyOTBweDtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoLi4vYXNzZXRzL2ltYWdlcy9iYW5uZXIxLmpwZyk7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cbi5iYW5uZXJfYXJlYSAuYmFubmVyOmJlZm9yZSB7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAwO1xuICBsZWZ0OiAwO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoLi4vYXNzZXRzL2ltYWdlcy9zYXBlNy5qcGcpO1xuICBiYWNrZ3JvdW5kLXNpemU6IDEwMCU7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgbWl4LWJsZW5kLW1vZGU6IHNjcmVlbjtcbn1cbi5iYW5uZXJfYXJlYSAuYmFubmVyIC5iYW5uZXJfY29udGFpbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAyNCU7XG4gIGxlZnQ6IDglO1xuICB3aWR0aDogNTAlO1xufVxuLmJhbm5lcl9hcmVhIC5iYW5uZXIgLmJhbm5lcl9jb250YWluIGgxIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGxpbmUtaGVpZ2h0OiBub3JtYWw7XG4gIGNvbG9yOiAjZmZmZmZmO1xuICBmb250LXNpemU6IDI0cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIHBhZGRpbmc6IDAgMDtcbiAgbWFyZ2luOiAwIDA7XG59XG4uYmFubmVyX2FyZWEgLmJhbm5lciAuYmFubmVyX2NvbnRhaW4gaDEgc3Ryb25nIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGNvbG9yOiAjMDk5ZmVhO1xuICBmb250LXdlaWdodDogNTAwO1xufVxuLnNlYXJjaF9hcmVhIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG59XG4uc2VhcmNoX2FyZWEgLnNlYXJjaCB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4uZm9ybS1jb250cm9sIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMzhweDtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgcGFkZGluZzogMTBweCA2NXB4IDEwcHggMTBweDtcbiAgYm9yZGVyOiAxcHggc29saWQgI2RhZGFkYTtcbiAgYm94LXNoYWRvdzogMCAwIDVweCByZ2IoMjI4IDIyOCAyMjggLyA3NiUpO1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBvdXRsaW5lOiBub25lO1xuICBiYWNrZ3JvdW5kOiByZ2IoMjI2IDIyNiAyMjYgLyAzMiUpO1xufVxuLnNlYXJjaF9hcmVhIC5zZWFyY2ggLmJ0bi1zZWFyY2gge1xuICBjb250ZW50OiBcIlwiO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogM3B4O1xuICByaWdodDogM3B4O1xuICBiYWNrZ3JvdW5kOiAjODZiZTQxO1xuICBib3JkZXI6IDFweCBzb2xpZCAjODZiZTQxO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBib3JkZXItcmFkaXVzOiAzMHB4O1xuICBwYWRkaW5nOiA0cHggMTRweDtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgb3V0bGluZTogbm9uZTtcbn1cbi5jYXRlZ29yeV9tYWluX2FyZWEge1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xufVxuLmNhdGVnb3J5X21haW5fYXJlYSAuY2F0ZWdvcnlfbGlzdGluZyB7XG4gIG92ZXJmbG93OiBzY3JvbGw7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG59XG4uY2F0ZWdvcnlfbWFpbl9hcmVhIC5jYXRlZ29yeV9saXN0aW5nIHVsIHtcbiAgbWFyZ2luOiAwO1xuICBwYWRkaW5nOiAwO1xuICBsaXN0LXN0eWxlOiBub25lO1xuICBkaXNwbGF5OiB0YWJsZTtcbiAgd2lkdGg6IDEwMCU7XG59XG4uY2F0ZWdvcnlfbWFpbl9hcmVhIC5jYXRlZ29yeV9saXN0aW5nIHVsIGxpIHtcbiAgZGlzcGxheTogdGFibGUtY2VsbDtcbiAgdmVydGljYWwtYWxpZ246IHRvcDtcbiAgbGlzdC1zdHlsZTogbm9uZTtcbn1cbi5jYXRlZ29yeV9ib3gge1xuICB3aWR0aDogMTEwcHg7XG4gIGhlaWdodDogODFweDtcbiAgcGFkZGluZzogMTBweCAxMHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tcmlnaHQ6IDhweDtcbn1cbi5jYXRlZ29yeV9ib3ggaDQge1xuICB3aWR0aDogMTAwJTtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgcGFkZGluZzogNHB4IDAgMDtcbiAgbWFyZ2luOiAwIDAgMDtcbiAgY29sb3I6ICMwMDAwMDA7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbn1cbi5jYXRlZ29yeV9ib3guYmcxIHtcbiAgYmFja2dyb3VuZDogI2ViZmZkMjtcbn1cbi5jYXRlZ29yeV9ib3guYmcyIHtcbiAgYmFja2dyb3VuZDogI2NiZWRmZjtcbn1cbi5jYXRlZ29yeV9ib3guYmczIHtcbiAgYmFja2dyb3VuZDogI2UxZTFlMTtcbn1cbi5jYXRlZ29yeV9ib3guYmc0IHtcbiAgYmFja2dyb3VuZDogI2ZlZTBlMDtcbn1cbnVsLmNvdXJzZV9saXN0aW5nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmc6IDAgMDtcbiAgbWFyZ2luOiAwIDA7XG59XG51bC5jb3Vyc2VfbGlzdGluZyBsaSB7XG4gIHdpZHRoOiA0OCU7XG4gIGZsb2F0OiBsZWZ0O1xuICBsaXN0LXN0eWxlOiBub25lO1xuICBtYXJnaW46IDAgOHB4IDEycHggMDtcbiAgcGFkZGluZzogMCAwO1xufVxudWwuY291cnNlX2xpc3RpbmcgbGk6bnRoLW9mLXR5cGUoMm4pIHtcbiAgd2lkdGg6IDQ5JTtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBtYXJnaW46IDAgMCAwIDA7XG59XG4uY291cnNlX2JveCB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBwYWRkaW5nOiAwIDA7XG4gIG1hcmdpbjogMCAwO1xufVxuLmNvdXJzZV9ib3ggLmltZ19ib3gge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMjZweDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgbWFyZ2luOiAwIDAgMTBweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cbi5jb3Vyc2VfYm94IC5pbWdfYm94IGltZyB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIG9iamVjdC1maXQ6IGNvdmVyO1xufVxuLmNvdXJzZV9ib3ggaDMge1xuICB3aWR0aDogMTAwJTtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgcGFkZGluZzogMCAwIDA7XG4gIG1hcmdpbjogMCAwIDNweDtcbiAgY29sb3I6ICMwMDAwMDA7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbn1cbi5jb3Vyc2VfYm94IHAge1xuICB3aWR0aDogMTAwJTtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgcGFkZGluZzogMCAwIDA7XG4gIG1hcmdpbjogMCAwIDVweDtcbiAgY29sb3I6ICMwMDAwMDA7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cbi5jb3Vyc2VfYm94IC5idG4ge1xuICBwYWRkaW5nOiAwIDAgMDtcbiAgbWFyZ2luOiAwIDAgMDtcbiAgY29sb3I6ICMxY2EzZWQ7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIGJvcmRlcjogbm9uZTtcbiAgb3V0bGluZTogbm9uZTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xufVxuXG4uYWJvdXRfYXJlYSB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBwYWRkaW5nOiAyMHB4IDBweDtcbn1cbi5hYm91dF9hcmVhIHVsIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIHBhZGRpbmc6IDAgMDtcbiAgbWFyZ2luOiAwIDA7XG4gIGxpc3Qtc3R5bGU6IG5vbmU7XG4gIGRpc3BsYXk6IHRhYmxlO1xufVxuLmFib3V0X2FyZWEgdWwgbGkge1xuICB3aWR0aDogNTAlO1xuICBkaXNwbGF5OiB0YWJsZS1jZWxsO1xuICB2ZXJ0aWNhbC1hbGlnbjogdG9wO1xuICBwYWRkaW5nOiAwIDA7XG4gIG1hcmdpbjogMCAwO1xufVxuLmFib3V0X2FyZWEgLmFib3V0X2ltZ19ib3gge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxNTRweDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xufVxuLmFib3V0X2FyZWEgLmFib3V0X2ltZ19ib3ggaW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgb2JqZWN0LWZpdDogY292ZXI7XG59XG4uYWJvdXRfYXJlYSAuYWJvdXRfY29udGFpbl9ib3gge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHdpZHRoOiAxMDAlO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBwYWRkaW5nOiAxMHB4IDEwcHg7XG59XG4uYWJvdXRfYXJlYSAuYWJvdXRfY29udGFpbl9ib3ggaDMge1xuICB3aWR0aDogMTAwJTtcbiAgbGluZS1oZWlnaHQ6IG5vcm1hbDtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBjb2xvcjogIzAwMDAwMDtcbiAgbWFyZ2luOiAwIDAgOHB4O1xufVxuLmFib3V0X2FyZWEgLmFib3V0X2NvbnRhaW5fYm94IHAge1xuICB3aWR0aDogMTAwJTtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgcGFkZGluZzogMCAwO1xuICBtYXJnaW46IDAgMDtcbiAgY29sb3I6ICMwMDAwMDA7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbn1cblxuLnNlcnZpY2VzX2FyZWEge1xuICB3aWR0aDogMTAwJTtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgcGFkZGluZzogMCAwIDA7XG4gIG1hcmdpbjogMCAwIDA7XG59XG4uc2VydmljZXNfYXJlYSBoMiB7XG4gIHdpZHRoOiAxMDAlO1xuICBsaW5lLWhlaWdodDogbm9ybWFsO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBmb250LXNpemU6IDE3cHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGNvbG9yOiAjMDAwMDAwO1xuICBtYXJnaW46IDAgMCAxMHB4O1xufVxuLnNlcnZpY2VzX2FyZWEgLnNlcnZpY2VfYm94IHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTcwcHg7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcbn1cbi5zZXJ2aWNlc19hcmVhIC5zZXJ2aWNlX2JveCBpbWcge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB6LWluZGV4OiAwO1xufVxuLnNlcnZpY2VzX2FyZWEgLnNlcnZpY2VfYm94IC5jb250YWluX2JveCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAwO1xuICBsZWZ0OiAwO1xuICB6LWluZGV4OiAxO1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZzogMTVweCAxNXB4O1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xufVxuLnNlcnZpY2VzX2FyZWEgLnNlcnZpY2VfYm94IC5jb250YWluX2JveCBoMyB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBsaW5lLWhlaWdodDogbm9ybWFsO1xuICBtYXJnaW46IDAgMCA1cHg7XG4gIHBhZGRpbmc6IDAgMDtcbiAgY29sb3I6ICNmZmZmZmY7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbn1cbi5zZXJ2aWNlc19hcmVhIC5zZXJ2aWNlX2JveCAuY29udGFpbl9ib3ggcCB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBwYWRkaW5nOiAwIDA7XG4gIG1hcmdpbjogMCAwO1xuICBjb2xvcjogI2ZmZmZmZjtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBmb250LXdlaWdodDogNDAwO1xuICBsaW5lLWhlaWdodDogMjBweDtcbn1cbi50b3BfY29sbGFnZV9ib3gge1xuICB3aWR0aDogMjkwcHg7XG4gIG1pbi1oZWlnaHQ6IDEwMnB4O1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHBhZGRpbmctbGVmdDogMTI1cHg7XG59XG4udG9wX2NvbGxhZ2VfYm94IC5pbWdfYm94IHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDA7XG4gIGxlZnQ6IDA7XG4gIHdpZHRoOiAxMThweDtcbiAgaGVpZ2h0OiAxMDJweDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xufVxuLnRvcF9jb2xsYWdlX2JveCAuaW1nX2JveCBpbWcge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBvYmplY3QtZml0OiBjb3Zlcjtcbn1cbi50b3BfY29sbGFnZV9ib3ggLmxpbmsge1xuICBvdXRsaW5lOiBub25lO1xuICB3aWR0aDogMTAwJTtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgY29sb3I6ICMwMDAwMDA7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgYm9yZGVyOiBub25lO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBmb250LXdlaWdodDogNTAwO1xuICBtYXJnaW46IDAgMCAxMHB4O1xufVxuLnRvcF9jb2xsYWdlX2JveCBwIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGxpbmUtaGVpZ2h0OiBub3JtYWw7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIG1hcmdpbjogMCAwO1xuICBwYWRkaW5nOiAwIDA7XG4gIGNvbG9yOiAjMTc4MWJhO1xuICBmb250LXNpemU6IDE1cHg7XG59XG4uY291cnNlc19ib3gge1xuICB3aWR0aDogMTAwJTtcbiAgbWluLWhlaWdodDogMTAwcHg7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgcGFkZGluZy1sZWZ0OiAxMTBweDtcbiAgcGFkZGluZy10b3A6IDVweDtcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcbn1cbi5jb3Vyc2VzX2JveCAuaW1nX2JveCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAwO1xuICBsZWZ0OiAwO1xuICB3aWR0aDogMTAwcHg7XG4gIGhlaWdodDogMTAwcHg7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG4uY291cnNlc19ib3ggLmltZ19ib3ggaW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgb2JqZWN0LWZpdDogY292ZXI7XG59XG4uY291cnNlc19ib3ggaDMge1xuICB3aWR0aDogMTAwJTtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgbWFyZ2luOiAwIDAgNXB4O1xuICBjb2xvcjogIzAzMTgyNjtcbiAgZm9udC1zaXplOiAxN3B4O1xuICBmb250LXdlaWdodDogNjAwO1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xufVxuLmNvdXJzZXNfYm94IGgzIHN0cm9uZyB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBjb2xvcjogIzEwOTdkYTtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBmb250LXdlaWdodDogNjAwO1xufVxuLmNvdXJzZXNfYm94IHAge1xuICB3aWR0aDogMTAwJTtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgcGFkZGluZzogMCAwIDA7XG4gIG1hcmdpbjogMCAwIDVweDtcbiAgY29sb3I6ICM3Njc2NzY7XG4gIGZvbnQtc2l6ZTogMTNweDtcbn1cbi5jb3Vyc2VzX2JveCAuYnRuX2xpbmsge1xuICBib3JkZXI6IG5vbmU7XG4gIG91dGxpbmU6IG5vbmU7XG4gIGNvbG9yOiAjMDk5ZmVhO1xuICBmb250LXNpemU6IDEycHg7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBwYWRkaW5nOiAwIDA7XG59XG4udy0yODUge1xuICB3aWR0aDogMjg1cHg7XG59XG4ub3VyX3BhcnRuZXJfYXJlYSB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHBhZGRpbmc6IDE1MnB4IDBweCA0MHB4O1xuICBtYXJnaW4tdG9wOiAtNzBweDtcbn1cbi5vdXJfcGFydG5lcl9hcmVhOmFmdGVyIHtcbiAgY29udGVudDogXCJcIjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDA7XG4gIGxlZnQ6IDA7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDI5MHB4O1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybCguLi9hc3NldHMvaW1hZ2VzL3NhcGU4LnBuZyk7XG59XG4ub3VyX3BhcnRuZXJfYXJlYSBoMyB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBwYWRkaW5nOiAwIDA7XG4gIG1hcmdpbjogMCAwIDE1cHg7XG4gIGNvbG9yOiAjZmZmZmZmO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHotaW5kZXg6IDE7XG59XG4ub3VyX3BhcnRuZXJfYXJlYSAucGFydG5lcl9jYXJhc2FsIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgei1pbmRleDogMTtcbn1cbi5wYXJ0bmVyX2JveCB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDYycHg7XG4gIG1hcmdpbjogMCA4cHggMCAwO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuLnBhcnRuZXJfYm94Omxhc3QtY2hpbGQge1xuICBtYXJnaW46IDAgMCAwIDA7XG59XG4ucGFydG5lcl9ib3ggaW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgb2JqZWN0LWZpdDogY292ZXI7XG59XG4ucGFydG5lcl9jYXJhc2FsIC5wYXJ0bmVyX25hdiB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBwYWRkaW5nOiAxMHB4IDBweCAwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5wYXJ0bmVyX2NhcmFzYWwgLnBhcnRuZXJfbmF2IC5idG4ge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIG91dGxpbmU6IG5vbmU7XG4gIHdpZHRoOiAxMHB4O1xuICBoZWlnaHQ6IDEwcHg7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZmZmZmY7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgcGFkZGluZzogMCAwO1xufVxuLnBhcnRuZXJfY2FyYXNhbCAucGFydG5lcl9uYXYgLmJ0bi5hY3RpdmUge1xuICBiYWNrZ3JvdW5kOiAjZmZmZmZmO1xufVxuXG4vKi0tLS0tLS0gbWVudSBjc3Mgc3RhcnQgLS0tLS0tLSovXG4ubWVudV9hcmVhIHtcbiAgY29udGVudDogXCJcIjtcbiAgcG9zaXRpb246IGZpeGVkO1xuICB0b3A6IDA7XG4gIGxlZnQ6IDA7XG4gIHdpZHRoOiAxMDAlO1xufVxuLm1lbnVfYXJlYSAubWVudV9wcm9maWxlIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMjcxcHg7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIC8qYmFja2dyb3VuZC1pbWFnZTogdXJsKC4uL2Fzc2V0cy9pbWFnZXMvbWVudS1iZy5qcGcpOyovXG4gIGJhY2tncm91bmQtY29sb3I6ICMwNzE2NjI7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIHBhZGRpbmc6IDI1cHggMjVweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLm1lbnVfYXJlYSAubWVudV9wcm9maWxlIC5tZW51X2ltZyB7XG4gIHdpZHRoOiAxMjBweDtcbiAgaGVpZ2h0OiAxMjBweDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgYm9yZGVyOiAycHggZGFzaGVkICNhNmQwN2U7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgbWFyZ2luOiAwIGF1dG8gMTVweDtcbiAgcGFkZGluZzogM3B4O1xufVxuLm1lbnVfYXJlYSAubWVudV9wcm9maWxlIC5tZW51X2ltZyBpbWcge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xufVxuLm1lbnVfYXJlYSAubWVudV9wcm9maWxlIGgxIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIHBhZGRpbmc6IDAgMDtcbiAgbWFyZ2luOiAwIDAgNXB4O1xuICBmb250LXNpemU6IDE4cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGNvbG9yOiAjZmZmO1xuICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcbiAgZm9udC1mYW1pbHk6ICdJbnRlciBSZWd1bGFyJztcbn1cbi5tZW51X2FyZWEgLm1lbnVfcHJvZmlsZSBwIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIHBhZGRpbmc6IDAgMDtcbiAgbWFyZ2luOiAwIDAgMDtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBmb250LXdlaWdodDogMzAwO1xuICBjb2xvcjogI2ZmZjtcbiAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG59XG4ubWVudV9hcmVhIC5tZW51X3Byb2ZpbGUgaDIge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHBhZGRpbmc6IDhweCAyMHB4O1xuICBmb250LXNpemU6IDE1cHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XG59XG4ubWVudV9hcmVhIC5tZW51X3Byb2ZpbGUgaDIgc3Ryb25nIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBjb2xvcjogIzhkYzYzZjtcbn1cblxuLm1lbnVfbmF2X2FyZWEge1xuICB3aWR0aDogMTAwJTtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgcGFkZGluZzogMjVweCAyNXB4O1xuICBvdmVyZmxvdzogYXV0bztcbiAgaGVpZ2h0OiAxMDB2aDtcbn1cbi5tZW51X25hdl9hcmVhIHVsIHtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmc6IDAgMDtcbiAgbWFyZ2luOiAwIDA7XG4gIG92ZXJmbG93OiBhdXRvO1xuICBtaW4taGVpZ2h0OiA0MDBweDtcbn1cbi5tZW51X25hdl9hcmVhIHVsIGxpIHtcbiAgcGFkZGluZzogMCAwO1xuICBtYXJnaW46IDAgMCAzMHB4O1xuICBsaXN0LXN0eWxlOiBub25lO1xufVxuLm1lbnVfbmF2X2FyZWEgdWwgbGkgLm1lbnVfbmF2IHtcbiAgY29sb3I6ICMwMDA7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG4gIGxldHRlci1zcGFjaW5nOiAxcHg7XG59XG4ubWVudV9uYXZfYXJlYSB1bCBsaSAubWVudV9uYXYgaSB7XG4gIGNvbG9yOiAjMWNhM2VkO1xufVxuLyotLS0tLS0tIG1lbnUgY3NzIHN0b3AgLS0tLS0tLSovXG4uYXBwLXZlcnNpb257XG4gIG1hcmdpbi10b3A6IC02cHg7XG4gICAgZm9udC1zaXplOiAxMXB4O1xuICAgIGNvbG9yOiAjMDcxNjYyO1xuICAgIGZvbnQtZmFtaWx5OiAnSW50ZXIgTWVkaXVtJztcbiAgICBmb250LXdlaWdodDogNjAwO1xufSJdfQ== */");

/***/ }),

/***/ 91106:
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\n  <ion-split-pane contentId=\"main-content\">\n    <ion-menu contentId=\"main-content\" type=\"overlay\">\n\n      <div class=\"body_warrper\">\n\n        <div class=\"menu_area\">\n          <div class=\"menu_profile\">\n            <div class=\"w-100\">\n              <div class=\"menu_img\" *ngIf=\"!userDetails?.profile_pic\">\n                <img src=\"assets/images/user.png\" alt=\"icon\" title=\"\">\n                \n                \n              </div>\n              <div class=\"menu_img\" *ngIf=\"userDetails?.profile_pic\">\n                <img src=\"{{imag_path + userDetails?.profile_pic}}\" alt=\"\">\n\n              </div>\n              <h1>{{userDetails?.code}}</h1>\n              <!-- <h1 *ngIf=\"!userDetails?.first_name\"></h1> -->\n              <p style=\"font-size: 21px;font-weight: bold;font-family: 'Inter Medium';\">{{userDetails?.full_name}}</p>\n\n            </div>\n            <div  class=\"profile_icon\" routerLink=\"/profile\" (click)=\"close()\">\n              <ion-icon  style=\"color: white;\n    border: 2px solid white;\n    padding: 7px;\n    border-radius: 30px;\" name=\"camera-outline\"></ion-icon>\n                 \n                </div>\n          </div>\n          <ion-grid>\n            <ion-list id=\"labels-list\" *ngIf=\"userDetails\">\n              <!--  <ion-list-header>Module</ion-list-header> -->\n              <ion-item lines=\"none\" routerLink=\"/attendence-b\" (click)=\"close()\">\n                <ion-icon slot=\"start\" ios=\"ios-calendar\" md=\"calendar-outline\"></ion-icon>\n                <ion-label>Attendance</ion-label>\n              </ion-item>\n              <!-- <ion-item lines=\"none\" routerLink=\"/attendence-expense\" (click)=\"close()\">\n                <ion-icon slot=\"start\" ios=\"bookmark-outline\" md=\"cart-outline\"></ion-icon>\n                <ion-label>Expense</ion-label>\n              </ion-item> -->\n               <ion-item lines=\"none\" routerLink=\"/workexpense-list\" (click)=\"close()\">\n                <ion-icon slot=\"start\" ios=\"bookmark-outline\" md=\"cart-outline\"></ion-icon>\n                <ion-label>Expense</ion-label>\n              </ion-item>\n              <ion-item lines=\"none\" routerLink=\"/wallet-page\" (click)=\"close()\">\n                <ion-icon slot=\"start\" ios=\"bookmark-outline\" md=\"wallet-outline\"></ion-icon>\n                <ion-label>Wallet</ion-label>\n              </ion-item>\n              <ion-item lines=\"none\" routerLink=\"/sallery-list\" (click)=\"close()\">\n                <ion-icon slot=\"start\" ios=\"bookmark-outline\" md=\"cash-outline\"></ion-icon>\n                <ion-label>Salary</ion-label>\n              </ion-item>\n              <ion-item lines=\"none\" routerLink=\"/leave-page\" (click)=\"close()\">\n                <ion-icon slot=\"start\" ios=\"bookmark-outline\" md=\"calendar-clear-outline\"></ion-icon>\n                <ion-label>Leave</ion-label>\n              </ion-item>\n              <ion-item lines=\"none\" routerLink=\"/attendence-report\" (click)=\"close()\">\n                <ion-icon slot=\"start\" ios=\"bookmark-outline\" md=\"book-outline\"></ion-icon>\n                <ion-label>Attendance Report</ion-label>\n              </ion-item>\n              <!-- <ion-item lines=\"none\" routerLink=\"/attendence-report\" (click)=\"close()\">\n            <ion-icon slot=\"start\" ios=\"bookmark-outline\" md=\"bookmark-sharp\"></ion-icon>\n            <ion-label>Profile</ion-label>\n          </ion-item>\n          <ion-item lines=\"none\" routerLink=\"/attendence-report\" (click)=\"close()\">\n            <ion-icon slot=\"start\" ios=\"bookmark-outline\" md=\"bookmark-sharp\"></ion-icon>\n            <ion-label>Change password</ion-label>\n          </ion-item> -->\n        \n              <ion-item *ngIf=\"userDetails\" lines=\"none\" (click)=\"logout()\">\n                <ion-icon slot=\"start\" ios=\"bookmark-outline\" md=\"log-out-outline\"></ion-icon>\n                <ion-label>Logout</ion-label>\n              </ion-item>\n\n            </ion-list>\n           <!--  <ion-list id=\"inbox-list\" *ngIf=\"userDetails\" style=\"\n        border-bottom: 1px #071662 solid;\n    \">\n            </ion-list> -->\n\n            <ion-list *ngIf=\"!userDetails\">\n              <ion-item *ngIf=\"!userDetails\" lines=\"none\" routerLink=\"/login\" (click)=\"close()\">\n                <ion-icon slot=\"start\" ios=\"bookmark-outline\" md=\"log-in-outline\"></ion-icon>\n                <ion-label>Login</ion-label>\n              </ion-item>\n\n            \n            </ion-list>\n\n           \n          </ion-grid>\n        </div>\n\n\n\n      </div>\n\n <p  *ngIf=\"ionVersionNumber\" style=\"text-align: center;\" class=\"app-version\">App version - {{ionVersionNumber}}</p>\n    </ion-menu>\n    <ion-router-outlet id=\"main-content\"></ion-router-outlet>\n  </ion-split-pane>\n</ion-app>");

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ "use strict";
/******/ 
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(8835)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map