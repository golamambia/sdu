package com.marianhello.bgloc.service;

public interface LocationServiceInfo {
    boolean isStarted();
    boolean isBound();
}
