(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["src_app_attendence_attendence_module_ts"],{

/***/ 50960:
/*!*********************************************************!*\
  !*** ./src/app/attendence/attendence-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendencePageRoutingModule": () => (/* binding */ AttendencePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _attendence_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./attendence.page */ 95216);




const routes = [
    {
        path: '',
        component: _attendence_page__WEBPACK_IMPORTED_MODULE_0__.AttendencePage
    }
];
let AttendencePageRoutingModule = class AttendencePageRoutingModule {
};
AttendencePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AttendencePageRoutingModule);



/***/ }),

/***/ 64913:
/*!*************************************************!*\
  !*** ./src/app/attendence/attendence.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendencePageModule": () => (/* binding */ AttendencePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _attendence_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./attendence-routing.module */ 50960);
/* harmony import */ var _attendence_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./attendence.page */ 95216);







let AttendencePageModule = class AttendencePageModule {
};
AttendencePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _attendence_routing_module__WEBPACK_IMPORTED_MODULE_0__.AttendencePageRoutingModule
        ],
        declarations: [_attendence_page__WEBPACK_IMPORTED_MODULE_1__.AttendencePage]
    })
], AttendencePageModule);



/***/ }),

/***/ 95216:
/*!***********************************************!*\
  !*** ./src/app/attendence/attendence.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendencePage": () => (/* binding */ AttendencePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_attendence_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./attendence.page.html */ 60442);
/* harmony import */ var _attendence_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./attendence.page.scss */ 16100);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ 24766);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ 58361);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 16274);




//import { Http, Headers, RequestOptions } from '@angular/http';










let AttendencePage = class AttendencePage {
    constructor(http, navCtrl, storage, loadingController, alertController, menu, fb, datePipe) {
        this.http = http;
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.menu = menu;
        this.fb = fb;
        this.datePipe = datePipe;
        this.minTime = '';
        this.maxTime = '18:30';
        this.newminTime = '';
        this.submitted = false;
        this.isLoading = false;
        this.subject_name = [];
        this.marks = [];
        this.percentage = [];
        this.document = [];
        this.depositData = [];
        this.clientCode = "";
        this.total_work_time = '';
        this.total_work_hrs = 0;
        this.total_work_min = 0;
        this.productForm = this.fb.group({
            quantities: this.fb.array([]),
        });
        this.storage.get("userDetails").then(val => {
            if (val) {
                this.userDetails = val;
                // this.userId=this.userDetails.response_data.id;
            }
        });
    }
    quantities() {
        return this.productForm.get("quantities");
    }
    newQuantity() {
        return this.fb.group({
            qty: '',
            price: '',
        });
    }
    addQuantity() {
        this.quantities().push(this.newQuantity());
    }
    removeQuantity(i) {
        this.quantities().removeAt(i);
    }
    ngOnInit() {
        this.storage.create();
        // this.storage.clear();
    }
    submit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: 'Sending...'
            });
            var headers = new Headers();
            //this.submitted = true;
            if (this.name == '' && this.name == null) {
                return;
            }
            else {
                yield loading.present();
                //var data ={}
                const data = new FormData();
                data.append("subject_name", JSON.stringify(this.subject_name));
                data.append("marks", JSON.stringify(this.marks));
                data.append("percentage", JSON.stringify(this.percentage));
                for (let i = 0; i < this.document.length; i++) {
                    data.append("document[]", this.document[i]);
                }
                //formData.append('data', JSON.stringify(data));
                this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'post-apply-form', data)
                    .subscribe((res) => {
                    //console.log(res.json());
                    res = res.json();
                    if (res.status == false) {
                        loading.dismiss();
                        this.alertController.create({
                            message: res.message,
                            buttons: ['OK']
                        }).then(resalert => {
                            resalert.present();
                        });
                    }
                    else if (res.status == true) {
                        //     this.fname='';
                        //     this.email='';
                        // this.phone='';
                        //  this.message='';
                        // this.alertController.create({
                        //    message: res.message,
                        //    buttons: ['OK']
                        //  }).then(resalert => {
                        //    resalert.present();
                        //  });
                        this.navCtrl.navigateForward('form-success/' + res.response_data);
                        loading.dismiss();
                    }
                    else {
                        this.alertController.create({
                            message: 'Something went wrong',
                            buttons: ['OK']
                        }).then(resalert => {
                            resalert.present();
                        });
                        loading.dismiss();
                    }
                }, (err) => {
                    //console.log(err);
                    loading.dismiss();
                });
            }
        });
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    importFile(event, index) {
        console.log(event);
        if (event.target.files && event.target.files.length > 0) {
            let files = event.target.files || event.dataTransfer.files;
            if (!files.length)
                return;
            var fileName = files[0].name.toUpperCase();
            this.document[index] = files[0];
            // if (fileName.endsWith(".JPG") || fileName.endsWith(".JPEG") || fileName.endsWith(".PNG")) {
            //   //console.log(files[0]);
            //   this.document[index] = files[0];
            // } else {
            //  this.document[index] = null;
            // }
        }
    }
    ionViewWillEnter() {
        this.storage.get("mintime").then((val) => {
            if (val) {
                let tm = this.datePipe.transform(val, 'hh:mm');
                this.newminTime = moment__WEBPACK_IMPORTED_MODULE_4__(tm, "hh:mm").add(1, 'minutes').format('hh:mm');
                this.minTime = tm;
                //moment(tm, "hh:mm").add(1, 'minutes').format('hh:mm');;
                //console.log( this.newminTime);
            }
            else {
                this.minTime = '09:30';
                this.newminTime = '09:31';
            }
        });
    }
    ionViewDidEnter() {
        //  this.storage.clear();
        this.reloadDepositData();
    }
    reloadDepositData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            //let d
            yield this.storage.forEach((value, key, index) => {
                if (key == 'attendenceData') {
                    //console.log(value.length);
                    var milliseconds = 0;
                    var lngth = 0;
                    this.depositData = value;
                    value.forEach(element => {
                        var parsedServerOutTime = moment__WEBPACK_IMPORTED_MODULE_4__(element.end_time24, "HH:mm");
                        var parsedServerInTime = moment__WEBPACK_IMPORTED_MODULE_4__(element.start_time24, "HH:mm");
                        milliseconds += parsedServerOutTime.diff(parsedServerInTime) / 1000;
                        lngth += 1;
                        if (value.length == lngth) {
                            let hours = Math.floor(milliseconds / 3600); // get hours
                            let minutes = Math.floor((milliseconds - (hours * 3600)) / 60);
                            if (hours) {
                                this.total_work_time = Math.abs(hours) + ' hrs ' + Math.abs(minutes) + ' min';
                                this.total_work_hrs = Math.abs(hours);
                                this.total_work_min = Math.abs(minutes);
                            }
                            else {
                                this.total_work_time = Math.abs(minutes) + ' mins';
                                this.total_work_hrs = Math.abs(hours);
                                this.total_work_min = Math.abs(minutes);
                            }
                        }
                        //console.log(lngth);
                        //let min=
                    });
                }
            });
        });
    }
    addAttendence() {
        this.navCtrl.navigateForward(['/attendence-single', {
            // clientName: 'test',
            }]);
    }
    edit_attendence(i, data) {
        this.navCtrl.navigateForward(['/attendence-single-edit', {
                index: i,
            }]);
    }
    remove_attendence(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                message: 'Are you sure to delete',
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            //console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'Okay',
                        handler: () => {
                            //console.log('Confirm Okay');
                            this.storage.forEach((value, key, index) => {
                                if (key == 'attendenceData') {
                                    value.forEach((val, key) => {
                                        if (key == id) {
                                            this.depositData.splice(key, 1);
                                            this.storage.remove(key).then((r) => {
                                                if (id == 0) {
                                                    this.storage.set("mintime", '');
                                                    this.total_work_time = '';
                                                }
                                                else {
                                                    value.forEach((val2, key2) => {
                                                        if (key2 == (id - 1)) {
                                                            //console.log(val2.mintime);
                                                            this.storage.set("mintime", val2.mintime);
                                                        }
                                                    });
                                                }
                                                this.storage.set('attendenceData', this.depositData).then((r) => {
                                                    ;
                                                    this.reloadDepositData();
                                                    // this.storage.set("mintime",'06:30');
                                                });
                                            });
                                        }
                                    });
                                }
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
AttendencePage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.MenuController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormBuilder },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_9__.DatePipe }
];
AttendencePage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-attendence',
        template: _raw_loader_attendence_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_attendence_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AttendencePage);



/***/ }),

/***/ 16100:
/*!*************************************************!*\
  !*** ./src/app/attendence/attendence.page.scss ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".list-header-md {\n  border-top: 0;\n}\n\n.segment-md .segment-button.activated, .segment-md .segment-button.segment-activated {\n  color: white;\n  border-color: #ffffff;\n  opacity: 1;\n  font-size: 14px;\n}\n\n.segment-md .segment-button {\n  color: white;\n  font-size: 14px;\n}\n\nion-segment-button.inner-segment.segment-button.segment-activated {\n  color: black;\n  border-color: black;\n}\n\nion-segment-button.inner-segment.segment-button {\n  color: lightgrey;\n  font-size: 14px;\n}\n\n.cs-header {\n  margin-bottom: 0;\n  background: white;\n  margin: 7px 0;\n  border-radius: 4px;\n}\n\n.checked {\n  color: green;\n}\n\n.cross {\n  color: red;\n}\n\n.backgrey {\n  background: rgba(0, 0, 0, 0.1);\n}\n\n.searchbar-md {\n  padding: 10px 0;\n}\n\n.cscard {\n  padding: 0;\n}\n\n.cscard .label-md {\n  margin: 0;\n}\n\n.cscard .item-md {\n  padding-left: 8px;\n}\n\n.cslist {\n  background: white;\n}\n\n.cslist .card-md {\n  margin: 0;\n  width: 100%;\n}\n\n.cslist .sc-ion-card-md-h {\n  margin-left: 0;\n  margin-right: 0;\n}\n\n.icon-big {\n  font-size: 1.6em;\n}\n\n.icon-right {\n  margin: 0;\n  padding: 0px;\n  line-height: 0;\n  float: right;\n}\n\n.back ion-item-sliding {\n  /*border: 1px solid #deeaff;*/\n  border-radius: 4px;\n  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.14), 0 3px 1px -2px rgba(0, 0, 0, 0.12), 0 1px 5px 0 rgba(0, 0, 0, 0.2);\n}\n\n.list-md {\n  margin: 0px 0 12px;\n}\n\n.list-md ion-item-options {\n  border-bottom: none;\n}\n\n.forward-icon {\n  font-size: 2em;\n}\n\n.bordered-row {\n  border: 1px solid gainsboro;\n  padding: 7px 0;\n  margin-bottom: 10px;\n  border-radius: 4px;\n}\n\n.bordered-row-slip {\n  border: 1px solid gainsboro;\n  padding: 1px 0;\n  margin-bottom: 10px;\n  border-radius: 4px;\n}\n\n.bordered-row-blue-slip {\n  border: 1px solid #0091ea;\n  padding: 1px 0;\n  margin-bottom: 10px;\n  border-radius: 4px;\n}\n\n.bordered-row-slip .label-md, .bordered-row-blue-slip .label-md {\n  margin: 3px 0px 3px 0;\n}\n\n.bordered-row-blue-slip .label-md, .bordered-row-blue-slip .text-input[disabled] {\n  color: #0091ea;\n}\n\n.bordered-row-blue-slip .item-button {\n  padding: 5px 8px;\n  height: auto;\n  font-size: 2.2rem;\n  box-shadow: none;\n}\n\n.back {\n  background: #f8f8f8;\n}\n\n.image_border {\n  border: 1px dashed lightgrey;\n  padding: 3px 3px 0px 3px;\n  border-radius: 6px;\n}\n\n.image_border img {\n  border-radius: 4px;\n  height: 35px;\n  width: 32px;\n}\n\n.list-title {\n  font-weight: 500;\n  color: #00364e;\n  font-size: 14px;\n}\n\n.list-title span {\n  color: #00b0ff;\n}\n\n.list-arrow {\n  color: #00b0ff;\n}\n\n.item-p {\n  color: #9e9e9e;\n}\n\n.pending-border {\n  border-left: 3px solid #ff0027;\n  margin-bottom: 12px;\n}\n\n.processing-border {\n  border-left: 3px solid #ffdc00;\n  margin-bottom: 12px;\n}\n\n.completed-border {\n  border-left: 3px solid #25e6c1;\n  margin-bottom: 12px;\n}\n\n.submitted-border {\n  border-left: 3px solid #00ab52;\n  margin-bottom: 12px;\n}\n\n.approved-border {\n  border-left: 3px solid #663399;\n  margin-bottom: 12px;\n}\n\n.back-grey {\n  background: #e8e8e8;\n  z-index: 9999999;\n}\n\nion-card-header {\n  font-weight: bold;\n}\n\n.nonet {\n  background: red;\n  color: white;\n  text-align: center;\n  width: 100%;\n  font-size: 14px;\n  z-index: 9999;\n}\n\n.smspan {\n  font-size: 12px;\n}\n\n.nomargin {\n  margin-top: 2px;\n  margin-bottom: 2px;\n}\n\n.shortmargin {\n  margin-right: 12px !important;\n}\n\n.margin {\n  margin-top: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF0dGVuZGVuY2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsYUFBQTtBQUNEOztBQUVBO0VBQ0MsWUFBQTtFQUNBLHFCQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7QUFDRDs7QUFFQTtFQUNDLFlBQUE7RUFDQSxlQUFBO0FBQ0Q7O0FBRUE7RUFDQyxZQUFBO0VBQ0EsbUJBQUE7QUFDRDs7QUFDQTtFQUNDLGdCQUFBO0VBQ0EsZUFBQTtBQUVEOztBQUFBO0VBQ0MsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtBQUdEOztBQURBO0VBQ0MsWUFBQTtBQUlEOztBQUZBO0VBQ0MsVUFBQTtBQUtEOztBQUhBO0VBQ0MsOEJBQUE7QUFNRDs7QUFKQTtFQUNDLGVBQUE7QUFPRDs7QUFMQTtFQUNDLFVBQUE7QUFRRDs7QUFOQTtFQUNDLFNBQUE7QUFTRDs7QUFQQTtFQUNDLGlCQUFBO0FBVUQ7O0FBUkE7RUFDQyxpQkFBQTtBQVdEOztBQVRBO0VBQ0MsU0FBQTtFQUNBLFdBQUE7QUFZRDs7QUFWQTtFQUNDLGNBQUE7RUFDQSxlQUFBO0FBYUQ7O0FBWEE7RUFDQyxnQkFBQTtBQWNEOztBQVpBO0VBQ0MsU0FBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQWVEOztBQWJBO0VBQ0MsNkJBQUE7RUFDQSxrQkFBQTtFQUVBLCtHQUFBO0FBZUQ7O0FBYkE7RUFDQyxrQkFBQTtBQWdCRDs7QUFkQTtFQUNDLG1CQUFBO0FBaUJEOztBQWZBO0VBQ0MsY0FBQTtBQWtCRDs7QUFoQkE7RUFDQywyQkFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBbUJEOztBQWpCQTtFQUNDLDJCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFvQkQ7O0FBbEJBO0VBQ0MseUJBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQXFCRDs7QUFuQkE7RUFDQyxxQkFBQTtBQXNCRDs7QUFwQkE7RUFDQyxjQUFBO0FBdUJEOztBQXJCQTtFQUNDLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUF3QkQ7O0FBdEJBO0VBQ0MsbUJBQUE7QUF5QkQ7O0FBdkJBO0VBQ0MsNEJBQUE7RUFDQSx3QkFBQTtFQUNBLGtCQUFBO0FBMEJEOztBQXhCQTtFQUNDLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUEyQkQ7O0FBekJBO0VBQ0MsZ0JBQUE7RUFDQSxjQUFBO0VBQ0csZUFBQTtBQTRCSjs7QUExQkE7RUFDQyxjQUFBO0FBNkJEOztBQTNCQTtFQUNDLGNBQUE7QUE4QkQ7O0FBNUJBO0VBQ0MsY0FBQTtBQStCRDs7QUE3QkE7RUFDQyw4QkFBQTtFQUNBLG1CQUFBO0FBZ0NEOztBQTlCQTtFQUNDLDhCQUFBO0VBQ0EsbUJBQUE7QUFpQ0Q7O0FBL0JBO0VBQ0MsOEJBQUE7RUFDQSxtQkFBQTtBQWtDRDs7QUFoQ0E7RUFDQyw4QkFBQTtFQUNBLG1CQUFBO0FBbUNEOztBQWpDQTtFQUNDLDhCQUFBO0VBQ0EsbUJBQUE7QUFvQ0Q7O0FBbENBO0VBQ0MsbUJBQUE7RUFDQSxnQkFBQTtBQXFDRDs7QUFsQ0E7RUFDQyxpQkFBQTtBQXFDRDs7QUFuQ0E7RUFDQyxlQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0FBc0NEOztBQXBDQTtFQUNJLGVBQUE7QUF1Q0o7O0FBckNBO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0FBd0NKOztBQXRDQTtFQUNJLDZCQUFBO0FBeUNKOztBQXZDQTtFQUNJLGVBQUE7QUEwQ0oiLCJmaWxlIjoiYXR0ZW5kZW5jZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubGlzdC1oZWFkZXItbWR7XHJcblx0Ym9yZGVyLXRvcDowO1xyXG59XHJcblxyXG4uc2VnbWVudC1tZCAuc2VnbWVudC1idXR0b24uYWN0aXZhdGVkLCAuc2VnbWVudC1tZCAuc2VnbWVudC1idXR0b24uc2VnbWVudC1hY3RpdmF0ZWQge1xyXG5cdGNvbG9yOiB3aGl0ZTtcclxuXHRib3JkZXItY29sb3I6ICNmZmZmZmY7XHJcblx0b3BhY2l0eTogMTtcclxuXHRmb250LXNpemU6MTRweDtcclxufVxyXG5cclxuLnNlZ21lbnQtbWQgLnNlZ21lbnQtYnV0dG9ue1xyXG5cdGNvbG9yOndoaXRlO1xyXG5cdGZvbnQtc2l6ZToxNHB4O1xyXG59XHJcblxyXG5pb24tc2VnbWVudC1idXR0b24uaW5uZXItc2VnbWVudC5zZWdtZW50LWJ1dHRvbi5zZWdtZW50LWFjdGl2YXRlZCB7XHJcblx0Y29sb3I6IGJsYWNrO1xyXG5cdGJvcmRlci1jb2xvcjogYmxhY2s7XHJcbn1cclxuaW9uLXNlZ21lbnQtYnV0dG9uLmlubmVyLXNlZ21lbnQuc2VnbWVudC1idXR0b24ge1xyXG5cdGNvbG9yOiBsaWdodGdyZXk7XHJcblx0Zm9udC1zaXplOiAxNHB4O1xyXG59XHJcbi5jcy1oZWFkZXJ7XHJcblx0bWFyZ2luLWJvdHRvbTogMDtcclxuXHRiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuXHRtYXJnaW46IDdweCAwO1xyXG5cdGJvcmRlci1yYWRpdXM6IDRweDtcclxufVxyXG4uY2hlY2tlZHtcclxuXHRjb2xvcjpncmVlbjtcclxufVxyXG4uY3Jvc3N7XHJcblx0Y29sb3I6cmVkO1xyXG59XHJcbi5iYWNrZ3JleXtcclxuXHRiYWNrZ3JvdW5kOnJnYmEoMCwwLDAsMC4xKTtcclxufVxyXG4uc2VhcmNoYmFyLW1ke1xyXG5cdHBhZGRpbmc6MTBweCAwO1xyXG59XHJcbi5jc2NhcmR7XHJcblx0cGFkZGluZzogMDtcclxufVxyXG4uY3NjYXJkIC5sYWJlbC1tZHtcclxuXHRtYXJnaW46IDA7XHJcbn1cclxuLmNzY2FyZCAuaXRlbS1tZHtcclxuXHRwYWRkaW5nLWxlZnQ6IDhweDtcclxufVxyXG4uY3NsaXN0e1xyXG5cdGJhY2tncm91bmQ6IHdoaXRlO1xyXG59XHJcbi5jc2xpc3QgLmNhcmQtbWR7XHJcblx0bWFyZ2luOjA7XHJcblx0d2lkdGg6IDEwMCU7XHJcbn1cclxuLmNzbGlzdCAuc2MtaW9uLWNhcmQtbWQtaHtcclxuXHRtYXJnaW4tbGVmdDogMDtcclxuXHRtYXJnaW4tcmlnaHQ6IDA7XHJcbn1cclxuLmljb24tYmlne1xyXG5cdGZvbnQtc2l6ZTogMS42ZW07XHJcbn1cclxuLmljb24tcmlnaHR7XHJcblx0bWFyZ2luOiAwO1xyXG5cdHBhZGRpbmc6IDBweDtcclxuXHRsaW5lLWhlaWdodDogMDtcclxuXHRmbG9hdDogcmlnaHQ7XHJcbn1cclxuLmJhY2sgaW9uLWl0ZW0tc2xpZGluZ3tcclxuXHQvKmJvcmRlcjogMXB4IHNvbGlkICNkZWVhZmY7Ki9cclxuXHRib3JkZXItcmFkaXVzOiA0cHg7XHJcblx0Ly8gYm94LXNoYWRvdzogMXB4IDFweCA1cHggbGlnaHRncmV5O1xyXG5cdGJveC1zaGFkb3c6IDAgMnB4IDJweCAwIHJnYmEoMCwwLDAsMC4xNCksMCAzcHggMXB4IC0ycHggcmdiYSgwLDAsMCwwLjEyKSwwIDFweCA1cHggMCByZ2JhKDAsMCwwLDAuMik7XHJcbn1cclxuLmxpc3QtbWQge1xyXG5cdG1hcmdpbjogMHB4IDAgMTJweDtcclxufVxyXG4ubGlzdC1tZCBpb24taXRlbS1vcHRpb25ze1xyXG5cdGJvcmRlci1ib3R0b206IG5vbmU7XHJcbn1cclxuLmZvcndhcmQtaWNvbntcclxuXHRmb250LXNpemU6IDJlbTtcclxufVxyXG4uYm9yZGVyZWQtcm93e1xyXG5cdGJvcmRlcjogMXB4IHNvbGlkIGdhaW5zYm9ybztcclxuXHRwYWRkaW5nOiA3cHggMDtcclxuXHRtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG5cdGJvcmRlci1yYWRpdXM6IDRweDtcclxufVxyXG4uYm9yZGVyZWQtcm93LXNsaXB7XHJcblx0Ym9yZGVyOiAxcHggc29saWQgZ2FpbnNib3JvO1xyXG5cdHBhZGRpbmc6IDFweCAwO1xyXG5cdG1hcmdpbi1ib3R0b206IDEwcHg7XHJcblx0Ym9yZGVyLXJhZGl1czogNHB4O1xyXG59XHJcbi5ib3JkZXJlZC1yb3ctYmx1ZS1zbGlwe1xyXG5cdGJvcmRlcjogMXB4IHNvbGlkICMwMDkxZWE7XHJcblx0cGFkZGluZzogMXB4IDA7XHJcblx0bWFyZ2luLWJvdHRvbTogMTBweDtcclxuXHRib3JkZXItcmFkaXVzOiA0cHg7XHJcbn1cclxuLmJvcmRlcmVkLXJvdy1zbGlwIC5sYWJlbC1tZCwgLmJvcmRlcmVkLXJvdy1ibHVlLXNsaXAgLmxhYmVsLW1ke1xyXG5cdG1hcmdpbjogM3B4IDBweCAzcHggMDtcclxufVxyXG4uYm9yZGVyZWQtcm93LWJsdWUtc2xpcCAubGFiZWwtbWQsIC5ib3JkZXJlZC1yb3ctYmx1ZS1zbGlwIC50ZXh0LWlucHV0W2Rpc2FibGVkXXtcclxuXHRjb2xvcjogIzAwOTFlYTtcclxufVxyXG4uYm9yZGVyZWQtcm93LWJsdWUtc2xpcCAuaXRlbS1idXR0b257XHJcblx0cGFkZGluZzogNXB4IDhweDtcclxuXHRoZWlnaHQ6IGF1dG87XHJcblx0Zm9udC1zaXplOiAyLjJyZW07XHJcblx0Ym94LXNoYWRvdzogbm9uZTtcclxufVxyXG4uYmFja3tcclxuXHRiYWNrZ3JvdW5kOiAjZjhmOGY4O1xyXG59XHJcbi5pbWFnZV9ib3JkZXJ7XHJcblx0Ym9yZGVyOiAxcHggZGFzaGVkIGxpZ2h0Z3JleTtcclxuXHRwYWRkaW5nOiAzcHggM3B4IDBweCAzcHg7XHJcblx0Ym9yZGVyLXJhZGl1czogNnB4O1xyXG59XHJcbi5pbWFnZV9ib3JkZXIgaW1ne1xyXG5cdGJvcmRlci1yYWRpdXM6IDRweDtcclxuXHRoZWlnaHQ6IDM1cHg7XHJcblx0d2lkdGg6IDMycHg7XHJcbn1cclxuLmxpc3QtdGl0bGV7XHJcblx0Zm9udC13ZWlnaHQ6IDUwMDtcclxuXHRjb2xvcjogIzAwMzY0ZTtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG4ubGlzdC10aXRsZSBzcGFue1xyXG5cdGNvbG9yOiAjMDBiMGZmO1xyXG59XHJcbi5saXN0LWFycm93e1xyXG5cdGNvbG9yOiAjMDBiMGZmO1xyXG59XHJcbi5pdGVtLXB7XHJcblx0Y29sb3I6ICM5ZTllOWU7XHJcbn1cclxuLnBlbmRpbmctYm9yZGVye1xyXG5cdGJvcmRlci1sZWZ0OiAzcHggc29saWQgI2ZmMDAyNztcclxuXHRtYXJnaW4tYm90dG9tOiAxMnB4O1xyXG59XHJcbi5wcm9jZXNzaW5nLWJvcmRlcntcclxuXHRib3JkZXItbGVmdDogM3B4IHNvbGlkICNmZmRjMDA7XHJcblx0bWFyZ2luLWJvdHRvbTogMTJweDtcclxufVxyXG4uY29tcGxldGVkLWJvcmRlcntcclxuXHRib3JkZXItbGVmdDogM3B4IHNvbGlkICMyNWU2YzE7XHJcblx0bWFyZ2luLWJvdHRvbTogMTJweDtcclxufVxyXG4uc3VibWl0dGVkLWJvcmRlcntcclxuXHRib3JkZXItbGVmdDogM3B4IHNvbGlkICMwMGFiNTI7XHJcblx0bWFyZ2luLWJvdHRvbTogMTJweDtcclxufVxyXG4uYXBwcm92ZWQtYm9yZGVye1xyXG5cdGJvcmRlci1sZWZ0OiAzcHggc29saWQgIzY2MzM5OTtcclxuXHRtYXJnaW4tYm90dG9tOiAxMnB4O1xyXG59XHJcbi5iYWNrLWdyZXl7XHJcblx0YmFja2dyb3VuZDogI2U4ZThlODtcclxuXHR6LWluZGV4Ojk5OTk5OTk7XHJcbn1cclxuXHJcbmlvbi1jYXJkLWhlYWRlciB7XHJcblx0Zm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuLm5vbmV0e1xyXG5cdGJhY2tncm91bmQ6IHJlZDtcclxuXHRjb2xvcjogd2hpdGU7XHJcblx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdHdpZHRoOiAxMDAlO1xyXG5cdGZvbnQtc2l6ZTogMTRweDtcclxuXHR6LWluZGV4OiA5OTk5O1xyXG59XHJcbi5zbXNwYW57XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbn1cclxuLm5vbWFyZ2lue1xyXG4gICAgbWFyZ2luLXRvcDogMnB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMnB4O1xyXG59XHJcbi5zaG9ydG1hcmdpbntcclxuICAgIG1hcmdpbi1yaWdodDogMTJweCAhaW1wb3J0YW50O1xyXG59XHJcbi5tYXJnaW57XHJcbiAgICBtYXJnaW4tdG9wOiA4cHg7XHJcbn0iXX0= */");

/***/ }),

/***/ 60442:
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/attendence/attendence.page.html ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (" <ion-header >\n  <ion-toolbar class=\"toolbar-background\">\n  <ion-buttons slot=\"start\" >\n   <ion-back-button class=\"button-native\"></ion-back-button>\n</ion-buttons>\n<ion-title class=\"toolbar-title\">Attendence Data</ion-title>\n  </ion-toolbar>\n</ion-header> \n<ion-content>\n\n<ion-content>\n\n    <ion-grid>\n      <ion-row color=\"primary\" justify-content-center>\n        <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\n          <!-- <div text-center>\n            <h3>Create your account!</h3>\n          </div> -->\n          <ion-grid>\n            <ion-item-divider *ngIf=\"total_work_time\" color=\"light\">Total work : <div> {{total_work_time}}</div></ion-item-divider>\n            <ion-row class=\"margin\">\n              <ion-col size=\"12\">\n                <div *ngFor=\"let inneritem of depositData; let i = index\">\n                  <ion-item-sliding #slidingItem1 class=\"submitted-border\">\n                    <ion-item lines=\"none\" color=\"grey\">\n                      <div slot=\"start\" class=\"shortmargin\">\n                        <h4>{{(i+1)}}</h4>\n                      </div>\n                      <ion-label class=\"nomargin\">  \n                          <ion-row>\n                            <ion-col size=\"6\">\n                              <h2 class=\"list-title\"><span class=\"smspan\">Project: {{depositData.length}} </span><br>{{inneritem.project}}</h2>\n                            </ion-col>\n                            <ion-col size=\"6\">\n                              <h2 class=\"list-title\"><span class=\"smspan\"> Time: </span><br>{{inneritem.start_time}} - {{ inneritem.end_time}}</h2>\n                            </ion-col>\n                            \n                          </ion-row>\n                        </ion-label>\n                        <a  slot=\"end\" (click)=\"edit_attendence(i,inneritem)\"> <ion-icon name=\"create-outline\"></ion-icon></a>\n                      <a style=\"margin-left: 22px;margin-right: -15px;\" *ngIf=\"depositData.length==i+1\" slot=\"end\" (click)=\"remove_attendence(i)\">  <ion-icon name=\"close-circle-outline\"></ion-icon></a>\n                    </ion-item>\n                  </ion-item-sliding>\n                </div>\n              </ion-col>\n              <ion-col size=\"12\" *ngIf=\"total_work_hrs<9\">\n                <div class=\"ion-text-center\">\n                <ion-button color=\"primary\" fill=\"outline\" (click)=\"addAttendence()\">\n                  <ion-icon slot=\"start\" name=\"add-circle-outline\"></ion-icon>\n                  Add Attendence\n                </ion-button>\n              </div>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n          <div padding *ngIf=\"total_work_hrs==9 && total_work_min==0\">\n            <ion-button  size=\"large\"  expand=\"block\">Submit</ion-button>\n          </div>\n          <div padding *ngIf=\"total_work_hrs!=9\">\n            <ion-button  size=\"large\"  [disabled]=\"true\"  expand=\"block\">Submit</ion-button>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n    \n \n  \n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_attendence_attendence_module_ts.js.map