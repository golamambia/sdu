(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["src_app_attendence-report_attendence-report_module_ts"],{

/***/ 2053:
/*!***********************************************************************!*\
  !*** ./src/app/attendence-report/attendence-report-routing.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendenceReportPageRoutingModule": () => (/* binding */ AttendenceReportPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _attendence_report_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./attendence-report.page */ 37892);




const routes = [
    {
        path: '',
        component: _attendence_report_page__WEBPACK_IMPORTED_MODULE_0__.AttendenceReportPage
    }
];
let AttendenceReportPageRoutingModule = class AttendenceReportPageRoutingModule {
};
AttendenceReportPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AttendenceReportPageRoutingModule);



/***/ }),

/***/ 86850:
/*!***************************************************************!*\
  !*** ./src/app/attendence-report/attendence-report.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendenceReportPageModule": () => (/* binding */ AttendenceReportPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _attendence_report_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./attendence-report-routing.module */ 2053);
/* harmony import */ var _attendence_report_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./attendence-report.page */ 37892);







let AttendenceReportPageModule = class AttendenceReportPageModule {
};
AttendenceReportPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _attendence_report_routing_module__WEBPACK_IMPORTED_MODULE_0__.AttendenceReportPageRoutingModule
        ],
        declarations: [_attendence_report_page__WEBPACK_IMPORTED_MODULE_1__.AttendenceReportPage]
    })
], AttendenceReportPageModule);



/***/ }),

/***/ 37892:
/*!*************************************************************!*\
  !*** ./src/app/attendence-report/attendence-report.page.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AttendenceReportPage": () => (/* binding */ AttendenceReportPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_attendence_report_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./attendence-report.page.html */ 46998);
/* harmony import */ var _attendence_report_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./attendence-report.page.scss */ 56256);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ 24766);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 16274);




//import { Http, Headers, RequestOptions } from '@angular/http';









let AttendenceReportPage = class AttendenceReportPage {
    constructor(http, navCtrl, storage, loadingController, alertController, menu, fb, datePipe) {
        this.http = http;
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.menu = menu;
        this.fb = fb;
        this.datePipe = datePipe;
        this.minTime = '';
        this.maxTime = '18:30';
        this.newminTime = '';
        this.submitted = false;
        this.isLoading = false;
        this.subject_name = [];
        this.marks = [];
        this.percentage = [];
        this.document = [];
        this.depositData = [];
        this.clientCode = "";
        this.total_amount = 0;
        this.total_work_hrs = 0;
        this.total_work_min = 0;
        this.project_list = '';
        this.search_project = '';
        this.search_date = '';
        this.total_workmonth_day = 0;
        this.total_work_day = 0;
        this.total_sun_day = 0;
        this.total_holiday_taken = 0;
        this.total_comp_day = 0;
        this.report_date = '';
        this.customPickerOptionFrom = {
            buttons: [
                {
                    text: 'clear',
                    handler: () => {
                        this.search_date = '';
                        this.reloadDepositData();
                        //this.ionCancel.emit();
                    }
                },
                {
                    text: 'cancel',
                    role: 'cancel',
                    handler: () => {
                        //console.log(123);
                    }
                },
                {
                    text: 'Done',
                    handler: (data) => {
                        // console.log(data);
                        var dt = data.year.value + '-' + data.month.value;
                        //convertDataToISO(this.datetimeValue);
                        this.search_date = dt;
                        //this.datePipe.transform(dt, 'Y-MM');
                        this.reloadDepositData();
                        // console.log(this.search_date);
                    }
                }
            ]
        };
        this.productForm = this.fb.group({
            quantities: this.fb.array([]),
        });
    }
    quantities() {
        return this.productForm.get("quantities");
    }
    newQuantity() {
        return this.fb.group({
            qty: '',
            price: '',
        });
    }
    addQuantity() {
        this.quantities().push(this.newQuantity());
    }
    removeQuantity(i) {
        this.quantities().removeAt(i);
    }
    ngOnInit() {
        this.storage.create();
        // this.storage.clear();
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    ionViewWillEnter() {
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                this.userDetails = val;
                this.userId = val.ID;
                this.getprojectList();
                this.reloadDepositData();
            }
            else {
                this.navCtrl.navigateForward('login');
            }
        });
    }
    ionViewDidEnter() {
        //  this.storage.clear();
    }
    reloadDepositData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            yield loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                //"search_project":this.search_project,
                "search_date": this.search_date,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'attendence-report-byuser', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.total_workmonth_day = res.total_days;
                    this.total_work_day = res.total_workingday;
                    this.total_sun_day = res.total_sunday;
                    this.report_date = res.rep_date;
                    this.total_holiday_taken = res.holiday_taken;
                    this.total_comp_day = res.comp_taken;
                }
                else {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                    this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    getprojectList() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            // await loading.present();
            //var data ={}
            var data = {
                "userid": 3,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-project-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.project_list = res.response_data;
                }
                else {
                    // this.alertController.create({
                    //  message: 'Something went wrong',
                    //   buttons: ['OK']
                    // }).then(resalert => {
                    //   resalert.present();
                    // });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    selectProject(id) {
        this.search_project = id;
        //console.log(id);
        this.reloadDepositData();
    }
    selectDate(dt) {
        //this.search_date = this.datePipe.transform(dt, 'Y-MM');
        //console.log(this.search_date);
        //this.reloadDepositData();
    }
    gotorequestpage() {
        this.navCtrl.navigateForward(['/return-request', {
            // clientName: 'test',
            }]);
    }
    edit_attendence(i, data) {
        this.navCtrl.navigateForward(['/attendence-single-edit', {
                index: i,
            }]);
    }
};
AttendenceReportPage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_8__.DatePipe }
];
AttendenceReportPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-attendence-report',
        template: _raw_loader_attendence_report_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_attendence_report_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AttendenceReportPage);



/***/ }),

/***/ 56256:
/*!***************************************************************!*\
  !*** ./src/app/attendence-report/attendence-report.page.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-grid {\n  margin-top: 10px;\n  padding-left: 10px;\n  padding-right: 10px;\n}\n\n.form-group {\n  margin: 0 0 10px !important;\n}\n\n.card-icon {\n  font-size: 40px !important;\n}\n\n.card-box {\n  margin-bottom: 6px !important;\n}\n\n.right-box-margin {\n  margin: 2px 2px 2px 16px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF0dGVuZGVuY2UtcmVwb3J0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUNBO0VBQ0UsMkJBQUE7QUFFRjs7QUFBQTtFQUNJLDBCQUFBO0FBR0o7O0FBQUE7RUFDTSw2QkFBQTtBQUdOOztBQUFBO0VBQ0ksbUNBQUE7QUFHSiIsImZpbGUiOiJhdHRlbmRlbmNlLXJlcG9ydC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tZ3JpZCB7XHJcbiAgbWFyZ2luLXRvcDogMTBweDtcclxuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbiAgcGFkZGluZy1yaWdodDogMTBweDtcclxufVxyXG4uZm9ybS1ncm91cCB7XHJcbiAgbWFyZ2luOiAwIDAgMTBweCAhaW1wb3J0YW50O1xyXG59XHJcbi5jYXJkLWljb24ge1xyXG4gICAgZm9udC1zaXplOiA0MHB4ICFpbXBvcnRhbnQ7XHJcbiAgIFxyXG59XHJcbi5jYXJkLWJveCB7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDZweCAhaW1wb3J0YW50O1xyXG4gICAgXHJcbn1cclxuLnJpZ2h0LWJveC1tYXJnaW4ge1xyXG4gICAgbWFyZ2luOiAycHggMnB4IDJweCAxNnB4ICFpbXBvcnRhbnQ7XHJcbn0iXX0= */");

/***/ }),

/***/ 46998:
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/attendence-report/attendence-report.page.html ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header >\n  <ion-toolbar class=\"toolbar-background\">\n  <ion-buttons slot=\"start\" >\n   <ion-back-button class=\"button-native\"></ion-back-button>\n</ion-buttons>\n<ion-title class=\"toolbar-title\">Attendance Report</ion-title>\n  </ion-toolbar>\n</ion-header> \n\n\n<ion-content>\n\n    <ion-grid>\n      <div class=\"card-box\" style=\"padding-top: 11px;\">\n                <ion-row >\n                                   \n\n         <ion-col align-self-center size=\"6\" >\n              <div class=\"form-group\"  >\n                <label class=\"time-lable\">Date</label>\n              \n               <ion-datetime [pickerOptions]=\"customPickerOptionFrom\" class=\"form-control\" #D (ionChange)=\"selectDate(D.value)\" placeholder=\"Date (M/Y)\" displayFormat=\"MMM/YYYY\"  [(ngModel)]=\"search_date\" [ngModelOptions]=\"{standalone: true}\" ></ion-datetime>\n              </div>\n              \n           \n            </ion-col>\n            <ion-col align-self-center size=\"6\" >\n              <div class=\"form-group\"  >\n                <label class=\"time-lable\">Report of </label>\n              <input class=\"form-control\" style=\"pointer-events: none;\" type=\"text\" name=\"\" value=\"{{report_date}}\">\n              \n              </div>\n              \n           \n            </ion-col>\n        </ion-row>\n           </div>\n         \n\n        <div>\n            <ion-row>\n              \n              <ion-col size=\"6\">\n                <div class=\"card-box\" >\n                <ion-row>\n                  <ion-col size=\"2\">\n                <ion-icon class=\"card-icon\" name=\"calendar-outline\"></ion-icon>\n                   </ion-col>\n                   <ion-col size=\"10\">\n                <div class=\"right-box-margin\">   <span class=\"title-today\" style=\"font-size: 12px;\" >Total working days</span> \n                 <p class=\"title-date\"> {{total_workmonth_day}}</p>\n                </div>\n                </ion-col>\n                </ion-row>\n                </div>\n              \n            </ion-col>\n           \n                 <ion-col size=\"6\">\n                <div class=\"card-box\" >\n                <ion-row>\n                  <ion-col size=\"2\">\n                <ion-icon class=\"card-icon\" name=\"calendar-outline\"></ion-icon>\n                   </ion-col>\n                   <ion-col size=\"10\">\n                <div class=\"right-box-margin\">   <span class=\"title-today\" >Working days</span> \n                 <p class=\"title-date\"> {{total_work_day}}</p>\n                </div>\n                </ion-col>\n                </ion-row>\n                </div>\n              \n             \n             \n            </ion-col>\n              <ion-col size=\"6\">\n                <div class=\"card-box\" >\n                <ion-row>\n                  <ion-col size=\"2\">\n                <ion-icon class=\"card-icon\" name=\"calendar-outline\"></ion-icon>\n                   </ion-col>\n                   <ion-col size=\"10\">\n                <div class=\"right-box-margin\">   <span class=\"title-today\"  >Sundays</span> \n                 <p class=\"title-date\"> {{total_sun_day}}</p>\n                </div>\n                </ion-col>\n                </ion-row>\n                </div>\n              \n            </ion-col>\n            <ion-col size=\"6\">\n                <div class=\"card-box\" >\n                <ion-row>\n                  <ion-col size=\"2\">\n                <ion-icon class=\"card-icon\" name=\"calendar-outline\"></ion-icon>\n                   </ion-col>\n                   <ion-col size=\"10\">\n                <div class=\"right-box-margin\">   <span class=\"title-today\">Holiday taken</span> \n                 <p class=\"title-date\"> {{total_holiday_taken}}</p>\n                </div>\n                </ion-col>\n                </ion-row>\n                </div>\n              \n            </ion-col>\n               <ion-col size=\"6\">\n                <div class=\"card-box\" >\n                <ion-row>\n                  <ion-col size=\"2\">\n                <ion-icon class=\"card-icon\" name=\"calendar-outline\"></ion-icon>\n                   </ion-col>\n                   <ion-col size=\"10\">\n                <div class=\"right-box-margin\">   <span class=\"title-today\"  >Comp taken</span> \n                 <p class=\"title-date\"> {{total_comp_day}}</p>\n                </div>\n                </ion-col>\n                </ion-row>\n                </div>\n              \n            </ion-col>\n                </ion-row>\n              </div>\n\n\n    </ion-grid>\n    \n  \n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_attendence-report_attendence-report_module_ts.js.map