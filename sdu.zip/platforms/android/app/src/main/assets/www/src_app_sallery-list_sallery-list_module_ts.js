(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["src_app_sallery-list_sallery-list_module_ts"],{

/***/ 12142:
/*!*************************************************************!*\
  !*** ./src/app/sallery-list/sallery-list-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SalleryListPageRoutingModule": () => (/* binding */ SalleryListPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _sallery_list_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sallery-list.page */ 33966);




const routes = [
    {
        path: '',
        component: _sallery_list_page__WEBPACK_IMPORTED_MODULE_0__.SalleryListPage
    }
];
let SalleryListPageRoutingModule = class SalleryListPageRoutingModule {
};
SalleryListPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SalleryListPageRoutingModule);



/***/ }),

/***/ 35493:
/*!*****************************************************!*\
  !*** ./src/app/sallery-list/sallery-list.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SalleryListPageModule": () => (/* binding */ SalleryListPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _sallery_list_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sallery-list-routing.module */ 12142);
/* harmony import */ var _sallery_list_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sallery-list.page */ 33966);







let SalleryListPageModule = class SalleryListPageModule {
};
SalleryListPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _sallery_list_routing_module__WEBPACK_IMPORTED_MODULE_0__.SalleryListPageRoutingModule
        ],
        declarations: [_sallery_list_page__WEBPACK_IMPORTED_MODULE_1__.SalleryListPage]
    })
], SalleryListPageModule);



/***/ }),

/***/ 33966:
/*!***************************************************!*\
  !*** ./src/app/sallery-list/sallery-list.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SalleryListPage": () => (/* binding */ SalleryListPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_sallery_list_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./sallery-list.page.html */ 34949);
/* harmony import */ var _sallery_list_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sallery-list.page.scss */ 88817);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ 24766);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 16274);




//import { Http, Headers, RequestOptions } from '@angular/http';









let SalleryListPage = class SalleryListPage {
    constructor(http, navCtrl, storage, loadingController, alertController, menu, fb, datePipe) {
        this.http = http;
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.menu = menu;
        this.fb = fb;
        this.datePipe = datePipe;
        this.minTime = '';
        this.maxTime = '18:30';
        this.newminTime = '';
        this.submitted = false;
        this.isLoading = false;
        this.subject_name = [];
        this.marks = [];
        this.percentage = [];
        this.document = [];
        this.depositData = [];
        this.clientCode = "";
        this.total_amount = 0;
        this.total_work_hrs = 0;
        this.total_work_min = 0;
        this.search_date = '';
        this.search_category = '';
        this.search_status = '';
        this.customPickerOptionFrom = {
            buttons: [
                {
                    text: 'clear',
                    handler: () => {
                        this.search_date = '';
                        this.reloadDepositData();
                        //this.ionCancel.emit();
                    }
                },
                {
                    text: 'cancel',
                    role: 'cancel',
                    handler: () => {
                        //console.log(123);
                    }
                },
                {
                    text: 'Done',
                    handler: (data) => {
                        // console.log(data);
                        var dt = data.year.value + '-' + data.month.value;
                        //convertDataToISO(this.datetimeValue);
                        this.search_date = dt;
                        this.reloadDepositData();
                        // console.log(this.search_date);
                    }
                }
            ]
        };
        this.productForm = this.fb.group({
            quantities: this.fb.array([]),
        });
    }
    quantities() {
        return this.productForm.get("quantities");
    }
    newQuantity() {
        return this.fb.group({
            qty: '',
            price: '',
        });
    }
    addQuantity() {
        this.quantities().push(this.newQuantity());
    }
    removeQuantity(i) {
        this.quantities().removeAt(i);
    }
    ngOnInit() {
        this.storage.create();
        // this.storage.clear();
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    ionViewWillEnter() {
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                this.userDetails = val;
                this.userId = val.ID;
                this.reloadDepositData();
            }
        });
    }
    ionViewDidEnter() {
        //  this.storage.clear();
    }
    reloadDepositData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            yield loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                "search_date": this.search_date,
                "search_status": this.search_status,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-sallery-transaction-getbyid', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                // console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                }
                else {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                    this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    doRefresh(event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            //await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                "search_date": this.search_date,
                "search_status": this.search_status,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-sallery-transaction-getbyid', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                // console.log(res);
                event.target.complete();
                loading.dismiss();
                if (res.status == true) {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                }
                else {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                    this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    selectDate(dt) {
        // this.search_date = this.datePipe.transform(dt, 'Y-MM-dd');
        // console.log(jj);
        //this.reloadDepositData();
    }
    selectStatus(id) {
        this.search_status = id;
        //console.log(id);
        this.reloadDepositData();
    }
    gotorequestpage() {
        this.navCtrl.navigateForward(['/return-request', {
            // clientName: 'test',
            }]);
    }
    edit_attendence(i, data) {
        this.navCtrl.navigateForward(['/attendence-single-edit', {
                index: i,
            }]);
    }
    remove_attendence(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                message: 'Are you sure to delete',
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            //console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'Okay',
                        handler: () => {
                            //console.log('Confirm Okay');
                            this.storage.forEach((value, key, index) => {
                                if (key == 'attendenceData') {
                                    value.forEach((val, key) => {
                                        if (key == id) {
                                            this.depositData.splice(key, 1);
                                            this.storage.remove(key).then((r) => {
                                                if (id == 0) {
                                                    this.storage.set("mintime", '');
                                                }
                                                else {
                                                    value.forEach((val2, key2) => {
                                                        if (key2 == (id - 1)) {
                                                            //console.log(val2.mintime);
                                                            this.storage.set("mintime", val2.mintime);
                                                        }
                                                    });
                                                }
                                                this.storage.set('attendenceData', this.depositData).then((r) => {
                                                    ;
                                                    this.reloadDepositData();
                                                    // this.storage.set("mintime",'06:30');
                                                });
                                            });
                                        }
                                    });
                                }
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
SalleryListPage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_8__.DatePipe }
];
SalleryListPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-sallery-list',
        template: _raw_loader_sallery_list_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_sallery_list_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SalleryListPage);



/***/ }),

/***/ 88817:
/*!*****************************************************!*\
  !*** ./src/app/sallery-list/sallery-list.page.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-grid {\n  margin-top: 10px;\n  padding-left: 10px;\n  padding-right: 10px;\n}\n\n.form-group {\n  margin: 0 0 10px !important;\n}\n\n.add-btn {\n  --ion-color-base: #071662 !important;\n  --ion-color-base-rgb: var(--ion-color-primary-rgb, 56, 128, 255) !important;\n  --ion-color-contrast: var(--ion-color-primary-contrast, #fff) !important;\n  --ion-color-contrast-rgb: var(\n    --ion-color-primary-contrast-rgb,\n    255,\n    255,\n    255\n  ) !important;\n  --ion-color-shade: #071662 !important;\n  --ion-color-tint: #071662 !important;\n  font-size: 12px;\n  font-family: \"Inter Regular\";\n  font-weight: 600;\n}\n\n.add-btn-icon {\n  color: #3bf5c2;\n  font-size: 30px;\n}\n\n.ref_btn {\n  padding-top: 8px !important;\n  padding-left: 9px !important;\n  border-radius: 9px !important;\n}\n\n.ion-badge {\n  right: 5px !important;\n}\n\n.ion-badge-suc {\n  right: 5px !important;\n}\n\n.rowcls {\n  height: 90px;\n}\n\n.inh2 {\n  color: #1ef3b9;\n  font-size: 15px !important;\n}\n\n.action-sheet-button22.action-sheet-button {\n  min-height: 147px !important;\n  overflow-y: scroll !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNhbGxlcnktbGlzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFDQTtFQUNFLDJCQUFBO0FBRUY7O0FBQUE7RUFDRSxvQ0FBQTtFQUNBLDJFQUFBO0VBQ0Esd0VBQUE7RUFDQTs7Ozs7Y0FBQTtFQU1BLHFDQUFBO0VBQ0Esb0NBQUE7RUFDQSxlQUFBO0VBQ0UsNEJBQUE7RUFDQSxnQkFBQTtBQUdKOztBQURBO0VBQ0UsY0FBQTtFQUNBLGVBQUE7QUFJRjs7QUFGQTtFQUNFLDJCQUFBO0VBQ0EsNEJBQUE7RUFDQSw2QkFBQTtBQUtGOztBQUhBO0VBRUkscUJBQUE7QUFLSjs7QUFISTtFQUVBLHFCQUFBO0FBS0o7O0FBSEk7RUFDQSxZQUFBO0FBTUo7O0FBSkk7RUFDQSxjQUFBO0VBQ0EsMEJBQUE7QUFPSjs7QUFMSTtFQUNGLDRCQUFBO0VBQ0UsNkJBQUE7QUFRSiIsImZpbGUiOiJzYWxsZXJ5LWxpc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWdyaWQge1xyXG4gIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gIHBhZGRpbmctcmlnaHQ6IDEwcHg7XHJcbn1cclxuLmZvcm0tZ3JvdXAge1xyXG4gIG1hcmdpbjogMCAwIDEwcHggIWltcG9ydGFudDtcclxufVxyXG4uYWRkLWJ0biB7XHJcbiAgLS1pb24tY29sb3ItYmFzZTogIzA3MTY2MiAhaW1wb3J0YW50O1xyXG4gIC0taW9uLWNvbG9yLWJhc2UtcmdiOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1yZ2IsIDU2LCAxMjgsIDI1NSkgIWltcG9ydGFudDtcclxuICAtLWlvbi1jb2xvci1jb250cmFzdDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QsICNmZmYpICFpbXBvcnRhbnQ7XHJcbiAgLS1pb24tY29sb3ItY29udHJhc3QtcmdiOiB2YXIoXHJcbiAgICAtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0LXJnYixcclxuICAgIDI1NSxcclxuICAgIDI1NSxcclxuICAgIDI1NVxyXG4gICkgIWltcG9ydGFudDtcclxuICAtLWlvbi1jb2xvci1zaGFkZTogIzA3MTY2MiAhaW1wb3J0YW50O1xyXG4gIC0taW9uLWNvbG9yLXRpbnQ6ICMwNzE2NjIgIWltcG9ydGFudDtcclxuICBmb250LXNpemU6IDEycHg7XHJcbiAgICBmb250LWZhbWlseTogJ0ludGVyIFJlZ3VsYXInO1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxufVxyXG4uYWRkLWJ0bi1pY29uIHtcclxuICBjb2xvcjogIzNiZjVjMjtcclxuICBmb250LXNpemU6IDMwcHg7XHJcbn1cclxuLnJlZl9idG4ge1xyXG4gIHBhZGRpbmctdG9wOiA4cHggIWltcG9ydGFudDtcclxuICBwYWRkaW5nLWxlZnQ6IDlweCAhaW1wb3J0YW50O1xyXG4gIGJvcmRlci1yYWRpdXM6IDlweCAhaW1wb3J0YW50O1xyXG59XHJcbi5pb24tYmFkZ2V7XHJcbiAgIFxyXG4gICAgcmlnaHQ6IDVweCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgLmlvbi1iYWRnZS1zdWN7XHJcbiAgIFxyXG4gICAgcmlnaHQ6IDVweCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgLnJvd2Nsc3tcclxuICAgIGhlaWdodDogOTBweDtcclxuICAgIH1cclxuICAgIC5pbmgye1xyXG4gICAgY29sb3I6ICMxZWYzYjk7XHJcbiAgICBmb250LXNpemU6IDE1cHggIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgIC5hY3Rpb24tc2hlZXQtYnV0dG9uMjIuYWN0aW9uLXNoZWV0LWJ1dHRvbntcclxuICBtaW4taGVpZ2h0OiAxNDdweCAhaW1wb3J0YW50O1xyXG4gICAgb3ZlcmZsb3cteTogc2Nyb2xsICFpbXBvcnRhbnQ7XHJcbn0iXX0= */");

/***/ }),

/***/ 34949:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sallery-list/sallery-list.page.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header >\n  <ion-toolbar class=\"toolbar-background\">\n  <ion-buttons slot=\"start\" >\n   <ion-back-button class=\"button-native\"></ion-back-button>\n</ion-buttons>\n<ion-title class=\"toolbar-title\">My Salary</ion-title>\n  </ion-toolbar>\n</ion-header> \n\n\n<ion-content>\n  <ion-refresher (ionRefresh)=\"doRefresh($event)\" slot=\"fixed\" pullFactor=\"0.5\" pullMin=\"100\" pullMax=\"200\">\n    <ion-refresher-content style=\"margin-top: 150px;\"></ion-refresher-content>\n  </ion-refresher>\n    <ion-grid>\n      <div class=\"card-box\" style=\"padding-top: 11px;\">\n                <ion-row >\n                                   \n\n         <ion-col align-self-center size=\"12\" >\n              <div class=\"form-group\"  >\n                <label class=\"time-lable\">Month & Year</label>\n              \n               <ion-datetime [pickerOptions]=\"customPickerOptionFrom\" class=\"form-control\" #D (ionChange)=\"selectDate(D.value)\" placeholder=\"Date (M/Y)\" displayFormat=\"MMM/YYYY\"  [(ngModel)]=\"search_date\" [ngModelOptions]=\"{standalone: true}\" ></ion-datetime>\n              </div>\n              \n           \n            </ion-col>\n        </ion-row>\n           </div>\n           \n\n              <div *ngFor=\"let inneritem of depositData; let i = index\" class=\"card-box\" style=\"padding-left: 0;\">\n                  \n                    <ion-row  class=\"rowcls\">\n                      <ion-col size=\"1\"  class=\"{{inneritem.us_status}}-col\">\n                        <h4 class=\"status-title\"><ion-badge  class=\"ion-badge-suc\" *ngIf=\"inneritem.us_status=='active'\">Success</ion-badge>\n                          <ion-badge class=\"ion-badge\" *ngIf=\"inneritem.us_status=='inactive'\">Pending</ion-badge>\n                          <ion-badge  class=\"ion-badge\" *ngIf=\"inneritem.us_status=='reject'\">Reject</ion-badge></h4>\n                      \n                      </ion-col>\n                      <ion-col size=\"11\" style=\"padding-left:11px\">\n                      <ion-label class=\"nomargin\">  \n                          <ion-row>\n                           <ion-col size=\"6\">\n                              <h2 class=\"list-title\"><span class=\"smspan\">Amount: </span><br>\n                             {{inneritem.us_amount}}\n                              </h2>\n                            </ion-col>\n                          \n                            <ion-col size=\"6\">\n                              <h2 class=\"list-title\"><span class=\"smspan\"> Date: </span><br>\n                                {{inneritem.us_pay_date | date:'MMM dd, yyyy'}}\n                              </h2>\n                            </ion-col>\n                                                     \n                            \n                          </ion-row>\n                          \n                        </ion-label>\n                      </ion-col>\n                    \n                  \n                </ion-row>\n             \n                </div>  \n                <div *ngIf=\"!depositData.length\">\n\n                  <ion-row>\n                    <ion-col size=\"12\">\n   <h2 class=\"list-title\" style=\"font-size: 22px;color: #af1313;text-align: center; font-weight: 600;\"> No record found \n                       \n                      </h2>\n                      </ion-col>\n                      </ion-row>\n                </div>\n           \n          \n    </ion-grid>\n\n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_sallery-list_sallery-list_module_ts.js.map