(self["webpackChunkerpmanagement"] = self["webpackChunkerpmanagement"] || []).push([["src_app_advance_advance_module_ts"],{

/***/ 41044:
/*!***************************************************!*\
  !*** ./src/app/advance/advance-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdvancePageRoutingModule": () => (/* binding */ AdvancePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 29535);
/* harmony import */ var _advance_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./advance.page */ 39370);




const routes = [
    {
        path: '',
        component: _advance_page__WEBPACK_IMPORTED_MODULE_0__.AdvancePage
    }
];
let AdvancePageRoutingModule = class AdvancePageRoutingModule {
};
AdvancePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AdvancePageRoutingModule);



/***/ }),

/***/ 68666:
/*!*******************************************!*\
  !*** ./src/app/advance/advance.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdvancePageModule": () => (/* binding */ AdvancePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _advance_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./advance-routing.module */ 41044);
/* harmony import */ var _advance_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./advance.page */ 39370);







let AdvancePageModule = class AdvancePageModule {
};
AdvancePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _advance_routing_module__WEBPACK_IMPORTED_MODULE_0__.AdvancePageRoutingModule
        ],
        declarations: [_advance_page__WEBPACK_IMPORTED_MODULE_1__.AdvancePage]
    })
], AdvancePageModule);



/***/ }),

/***/ 39370:
/*!*****************************************!*\
  !*** ./src/app/advance/advance.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdvancePage": () => (/* binding */ AdvancePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_advance_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./advance.page.html */ 36924);
/* harmony import */ var _advance_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./advance.page.scss */ 48413);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 31887);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 34595);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 72604);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ 24766);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 93324);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 16274);
/* harmony import */ var _component_advance_advance_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../component/advance/advance.component */ 94224);




//import { Http, Headers, RequestOptions } from '@angular/http';












let AdvancePage = class AdvancePage {
    constructor(http, navCtrl, storage, loadingController, alertController, menu, fb, datePipe, actionSheetController, popoverCtrl, popoverController
    //public events: Events
    ) {
        this.http = http;
        this.navCtrl = navCtrl;
        this.storage = storage;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.menu = menu;
        this.fb = fb;
        this.datePipe = datePipe;
        this.actionSheetController = actionSheetController;
        this.popoverCtrl = popoverCtrl;
        this.popoverController = popoverController;
        this.today = Date.now();
        this.minTime = '';
        this.maxTime = '18:30';
        this.newminTime = '';
        this.submitted = false;
        this.isLoading = false;
        this.subject_name = [];
        this.marks = [];
        this.percentage = [];
        this.document = [];
        this.depositData = [];
        this.clientCode = "";
        this.total_amount = 0;
        this.total_work_hrs = 0;
        this.total_work_min = 0;
        this.project_list = '';
        this.search_project = '';
        this.search_date = '';
        this.search_category = '';
        this.search_status = '';
        this.category_list = '';
        this.customPickerOptionFrom = {
            buttons: [
                {
                    text: 'clear',
                    handler: () => {
                        this.search_date = '';
                        this.reloadDepositData();
                        //this.ionCancel.emit();
                    }
                },
                {
                    text: 'cancel',
                    role: 'cancel',
                    handler: () => {
                        //console.log(123);
                    }
                },
                {
                    text: 'Done',
                    handler: (data) => {
                        console.log(data);
                        var dt = data.year.value + '-' + data.month.value + '-' + data.day.text;
                        //convertDataToISO(this.datetimeValue);
                        this.search_date = dt;
                        //this.datePipe.transform(dt, 'Y-MM-dd');
                        this.reloadDepositData();
                        // console.log(this.search_date);
                        // console.log(dt);
                    }
                }
            ]
        };
        this.productForm = this.fb.group({
            quantities: this.fb.array([]),
        });
    }
    quantities() {
        return this.productForm.get("quantities");
    }
    newQuantity() {
        return this.fb.group({
            qty: '',
            price: '',
        });
    }
    addQuantity() {
        this.quantities().push(this.newQuantity());
    }
    removeQuantity(i) {
        this.quantities().removeAt(i);
    }
    ngOnInit() {
        this.storage.create();
        // this.storage.clear();
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    ionViewWillEnter() {
        this.storage.get("genuserDetails").then(val => {
            if (val) {
                this.userDetails = val;
                this.userId = val.ID;
                this.getprojectList();
                this.getcategoryList();
                this.reloadDepositData();
            }
            else {
                this.navCtrl.navigateForward('login');
            }
        });
    }
    ionViewDidEnter() {
        //  this.storage.clear();
    }
    reloadDepositData() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.userId);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            yield loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                "search_project": this.search_project,
                "search_date": this.search_date,
                "search_category": this.search_category,
                "search_status": this.search_status,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-advance-request-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                }
                else {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                    this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    doRefresh(event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            //await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                "search_project": this.search_project,
                "search_date": this.search_date,
                "search_category": this.search_category,
                "search_status": this.search_status,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-advance-request-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                event.target.complete();
                loading.dismiss();
                if (res.status == true) {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                }
                else {
                    this.depositData = res.response_data;
                    this.total_amount = res.total_amount;
                    this.alertController.create({
                        message: 'Something went wrong',
                        buttons: ['OK']
                    }).then(resalert => {
                        resalert.present();
                    });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    getprojectList() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            // await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-project-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.project_list = res.response_data;
                }
                else {
                    // this.alertController.create({
                    //  message: 'Something went wrong',
                    //   buttons: ['OK']
                    // }).then(resalert => {
                    //   resalert.present();
                    // });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    getcategoryList() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            //console.log(this.subject_name);
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            //this.submitted = true;
            // await loading.present();
            //var data ={}
            var data = {
                "userid": this.userId,
                //this.password
            };
            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'expense-category-get', JSON.stringify(data), { headers: headers })
                .subscribe((res) => {
                //console.log(res);
                loading.dismiss();
                if (res.status == true) {
                    this.category_list = res.response_data;
                }
                else {
                    // this.alertController.create({
                    //  message: 'Something went wrong',
                    //   buttons: ['OK']
                    // }).then(resalert => {
                    //   resalert.present();
                    // });
                    loading.dismiss();
                }
            }, (err) => {
                //console.log(err);
                loading.dismiss();
            });
        });
    }
    selectProject(id) {
        this.search_project = id;
        //console.log(id);
        this.reloadDepositData();
    }
    selectDate(dt) {
        //this.search_date = this.datePipe.transform(dt, 'Y-MM-dd');
        // console.log(jj);
        //this.reloadDepositData();
    }
    selectCategory(id) {
        this.search_category = id;
        //console.log(id);
        this.reloadDepositData();
    }
    selectStatus(id) {
        this.search_status = id;
        //console.log(id);
        this.reloadDepositData();
    }
    gotorequestpage() {
        this.navCtrl.navigateForward(['/return-request', {
            // clientName: 'test',
            }]);
    }
    edit_expense(id) {
        this.navCtrl.navigateForward(['/advance-request-edit', {
                id: id,
            }]);
    }
    edit_attendence(i, data) {
        this.navCtrl.navigateForward(['/attendence-single-edit', {
                index: i,
            }]);
    }
    remove_attendence(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                message: 'Are you sure to delete',
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            //console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'Okay',
                        handler: () => {
                            //console.log('Confirm Okay');
                            this.storage.forEach((value, key, index) => {
                                if (key == 'attendenceData') {
                                    value.forEach((val, key) => {
                                        if (key == id) {
                                            this.depositData.splice(key, 1);
                                            this.storage.remove(key).then((r) => {
                                                if (id == 0) {
                                                    this.storage.set("mintime", '');
                                                }
                                                else {
                                                    value.forEach((val2, key2) => {
                                                        if (key2 == (id - 1)) {
                                                            //console.log(val2.mintime);
                                                            this.storage.set("mintime", val2.mintime);
                                                        }
                                                    });
                                                }
                                                this.storage.set('attendenceData', this.depositData).then((r) => {
                                                    ;
                                                    this.reloadDepositData();
                                                    // this.storage.set("mintime",'06:30');
                                                });
                                            });
                                        }
                                    });
                                }
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    remove_expense(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: ''
            });
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpHeaders();
            headers.append('content-type', 'application/json; charset=utf-8');
            const alert = yield this.alertController.create({
                message: 'Are you sure to delete',
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            //console.log('Confirm Cancel: blah');
                        }
                    },
                    {
                        text: 'Okay',
                        handler: () => {
                            //console.log('Confirm Okay');
                            loading.present();
                            let localarray = {
                                "userid": this.userId,
                                "id": id,
                                //"address":this.address,
                            };
                            //console.log(this.end_time);
                            this.http.post(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.host + 'user-advance-request-deletebyid', JSON.stringify(localarray), { headers: headers })
                                .subscribe((res) => {
                                // console.log(res);
                                loading.dismiss();
                                if (res.status == true) {
                                    this.reloadDepositData();
                                    this.alertController.create({
                                        message: 'Successfully deleted',
                                        buttons: ['OK']
                                    }).then(resalert => {
                                        resalert.present();
                                    });
                                }
                                else {
                                    this.alertController.create({
                                        message: 'Something went wrong',
                                        buttons: ['OK']
                                    }).then(resalert => {
                                        resalert.present();
                                    });
                                    loading.dismiss();
                                }
                            }, (err) => {
                                //console.log(err);
                                loading.dismiss();
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    detailsView(desc, rejt, project) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            var button_array = [
                { text: 'Project : ' + project },
                { text: 'Description : ' + desc },
            ];
            if (rejt) {
                button_array.push({ text: 'Reject reason : ' + rejt });
            }
            const actionSheet = yield this.actionSheetController.create({
                header: "Short Details",
                cssClass: 'my-custom-class',
                buttons: button_array,
            });
            yield actionSheet.present();
        });
    }
    settingsPopover(ev) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const siteInfo = { id: 1, name: 'edupala' };
            const popover = yield this.popoverController.create({
                component: _component_advance_advance_component__WEBPACK_IMPORTED_MODULE_4__.AdvanceComponent,
                event: ev,
                cssClass: 'popover_setting',
                componentProps: {
                    site: siteInfo
                },
                translucent: true
            });
            popover.onDidDismiss().then((result) => {
                //console.log(result.data);
            });
            return yield popover.present();
            /** Sync event from popover component */
        });
    }
};
AdvancePage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.MenuController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormBuilder },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_9__.DatePipe },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ActionSheetController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.PopoverController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.PopoverController }
];
AdvancePage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-advance',
        template: _raw_loader_advance_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_advance_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AdvancePage);



/***/ }),

/***/ 94224:
/*!********************************************************!*\
  !*** ./src/app/component/advance/advance.component.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdvanceComponent": () => (/* binding */ AdvanceComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 61855);
/* harmony import */ var _raw_loader_advance_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./advance.component.html */ 50444);
/* harmony import */ var _advance_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./advance.component.scss */ 98);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 42741);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 34595);





let AdvanceComponent = class AdvanceComponent {
    constructor(popoverController, navCtrl) {
        this.popoverController = popoverController;
        this.navCtrl = navCtrl;
    }
    ngOnInit() { }
    popDismiss(page) {
        this.popoverController.dismiss();
        this.navCtrl.navigateForward('/' + page);
    }
};
AdvanceComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.PopoverController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController }
];
AdvanceComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-advance',
        template: _raw_loader_advance_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_advance_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AdvanceComponent);



/***/ }),

/***/ 48413:
/*!*******************************************!*\
  !*** ./src/app/advance/advance.page.scss ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhZHZhbmNlLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ 98:
/*!**********************************************************!*\
  !*** ./src/app/component/advance/advance.component.scss ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhZHZhbmNlLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ 36924:
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/advance/advance.page.html ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header >\n  <ion-toolbar class=\"toolbar-background\">\n  <ion-buttons slot=\"start\" >\n   <ion-back-button class=\"button-native\"></ion-back-button>\n</ion-buttons>\n<ion-buttons slot=\"primary\">\n  <ion-button (click)=\"settingsPopover()\">\n    <ion-icon style=\"color:white;\" slot=\"icon-only\" ios=\"ellipsis-horizontal\" md=\"ellipsis-vertical\"></ion-icon>\n  </ion-button>\n</ion-buttons>\n<ion-title class=\"toolbar-title\">Advance Request</ion-title>\n\n  </ion-toolbar>\n</ion-header> \n\n\n<ion-content>\n  <ion-refresher (ionRefresh)=\"doRefresh($event)\" slot=\"fixed\" pullFactor=\"0.5\" pullMin=\"100\" pullMax=\"200\">\n    <ion-refresher-content style=\"margin-top: 150px;\"></ion-refresher-content>\n  </ion-refresher>\n    <ion-grid>\n      \n               \n            <div>\n            <ion-row>\n              <ion-col size=\"6\">\n                <div class=\"card-box\" >\n                <ion-row>\n                  <ion-col size=\"2\">\n                <ion-icon class=\"card-icon\" name=\"calendar-outline\"></ion-icon>\n                   </ion-col>\n                   <ion-col size=\"10\">\n                <div class=\"right-box-margin\">   <span class=\"title-today\">Today</span> \n                 <p class=\"title-date\"> {{today |  date: 'dd MMM, yyyy'}}</p>\n                </div>\n                </ion-col>\n                </ion-row>\n                </div>\n              \n             \n             \n            </ion-col>\n           \n                \n              <ion-col size=\"6\">\n                <div class=\"card-box\" >\n                  <ion-row>\n                    <ion-col size=\"2\">\n                  <ion-icon class=\"card-icon\" name=\"wallet-outline\"></ion-icon>\n                     </ion-col>\n                     <ion-col size=\"10\">\n                  <div class=\"right-box-margin\">   <span class=\"title-today\">Balance</span> \n                   <p class=\"title-date\">₹ {{total_amount}}</p>\n                  </div>\n                  </ion-col>\n                  </ion-row>\n                  </div>\n                \n                </ion-col>\n               \n                </ion-row>\n              </div>\n              <div class=\"card-box\" style=\"padding-top: 11px;\">\n                <ion-row >\n                  <ion-col align-self-center size=\"6\" >\n                    <div class=\"form-group\">\n                      <label>Project</label>\n                       <select #P (change)=\"selectProject(P.value)\" class=\"form-control\" [(ngModel)]=\"search_project\" [ngModelOptions]=\"{standalone: true}\">\n                      <option value=\"\" selected=\"selected\">Select all</option>\n                      <option *ngFor=\"let val of project_list; let i = index\" value=\"{{val.sub_project_id}}\">{{val.project_name+' ('+val.project_id+')'}} > {{val.sub_project_name+' ('+val.sub_project_id+')'}}  </option>\n                    </select>\n                      <div class=\"arrow\"><img src=\"assets/images/select-arrow.png\" alt=\"select arrow\" title=\"\" /></div>\n                  </div>\n                   \n                  \n             </ion-col>\n             <ion-col align-self-center size=\"6\" >\n              <div class=\"form-group\"  >\n                <label class=\"time-lable\">Date</label>\n              \n                <ion-datetime [pickerOptions]=\"customPickerOptionFrom\" #D (ionChange)=\"selectDate(D.value)\" class=\"form-control\" placeholder=\"Date (D/M/Y)\" [min]=\"minDate\"  displayFormat=\"DD/MMM/YYYY\"  [(ngModel)]=\"search_date\" [ngModelOptions]=\"{standalone: true}\" ></ion-datetime>\n              </div>\n              \n           \n            </ion-col>\n            \n              <!-- <ion-col align-self-center size=\"6\" >\n                <div class=\"form-group\">\n                  <label>Category</label>\n                   <select class=\"form-control\" #C (change)=\"selectCategory(C.value)\" [(ngModel)]=\"search_category\" [ngModelOptions]=\"{standalone: true}\">\n                  <option value=\"\" selected=\"selected\">Select all</option>\n                  <option *ngFor=\"let val of category_list; let i = index\" value=\"{{val.ec_ID}}\">{{val.ec_name}}</option>\n                </select>\n                  <div class=\"arrow\"><img src=\"assets/images/select-arrow.png\" alt=\"select arrow\" title=\"\" /></div>\n              </div>\n                \n         </ion-col> -->\n         <ion-col align-self-center size=\"6\" >\n          <div class=\"form-group\">\n            <label>Status</label>\n             <select #S (change)=\"selectStatus(S.value)\" class=\"form-control\" [(ngModel)]=\"search_status\" [ngModelOptions]=\"{standalone: true}\">\n              <option value=\"\" selected=\"selected\">Select all</option>\n              <option value=\"pending\">Partially Approved</option>\n              <option value=\"active\">Approved</option>\n              <option value=\"payment_done\">Paid</option>\n              <option value=\"inactive\">Pending</option>\n              <option value=\"reject\">Reject</option>\n              \n          </select>\n            <div class=\"arrow\"><img src=\"assets/images/select-arrow.png\" alt=\"select arrow\" title=\"\" /></div>\n        </div>\n               \n        </ion-col>\n        </ion-row>\n           </div>\n            \n                <div *ngFor=\"let inneritem of depositData; let i = index\" class=\"card-box\" style=\"padding-left: 0;\">\n                  \n                    <ion-row >\n                      <ion-col size=\"1\" class=\"{{inneritem.status}}-col\" (click)=\"detailsView(inneritem.uar_description,inneritem.uar_reject,inneritem.project_name)\">\n                        <h4 class=\"status-title\"><ion-badge  class=\"ion-badge-suc\" *ngIf=\"inneritem.status=='active'\">Approved</ion-badge>\n                          <ion-badge  class=\"ion-badge-done\" *ngIf=\"inneritem.status=='payment_done'\">Paid</ion-badge>\n                          <ion-badge class=\"ion-badge\" *ngIf=\"inneritem.status=='inactive'\">Pending</ion-badge>\n                          <ion-badge  class=\"ion-badge\" *ngIf=\"inneritem.status=='reject'\">Reject</ion-badge>\n                          <ion-badge class=\"ion-badge-pend\" *ngIf=\"inneritem.status=='pending'\">Part Approved</ion-badge></h4>\n                      </ion-col>\n                      <ion-col size=\"11\" style=\"padding-left:11px\">\n                      <ion-label class=\"nomargin\">  \n                          <ion-row (click)=\"detailsView(inneritem.uar_description,inneritem.uar_reject,inneritem.project_name)\">\n                            <ion-col size=\"12\">\n                              <h2 class=\"list-title\"><span class=\"smspan\">Project </span><br>\n                                {{inneritem.project_name.length > 50 ? inneritem.project_name.slice(0, 50) + \"...\" : inneritem.project_name }}\n                               \n                              </h2>\n                            </ion-col>\n                            \n                                                      \n                            \n                          </ion-row>\n                          <ion-row>\n                            <ion-col size=\"6\" (click)=\"detailsView(inneritem.uar_description,inneritem.uar_reject,inneritem.project_name)\">\n                              <h2 class=\"list-title\"><span class=\"smspan\"> Date </span><br>\n                                {{inneritem.uar_checkindate | date:'MMM dd, yyyy'}}\n                              </h2>\n                            </ion-col>\n                            <ion-col size=\"6\" (click)=\"detailsView(inneritem.uar_description,inneritem.uar_reject,inneritem.project_name)\">\n                              <h2 class=\"list-title\"><span class=\"smspan\">Amount </span><br>{{inneritem.uar_amount}}\n                              <!-- <span *ngIf=\"inneritem.uw_debit_credit=='dr'\" style=\"color: black;\">-Cr</span>\n                              <span *ngIf=\"inneritem.uw_debit_credit=='cr'\" style=\"color: black;\">-Dr</span> -->\n                              </h2>\n                            </ion-col>\n                            <!-- <ion-col size=\"4\" (click)=\"detailsView(inneritem.uar_description,inneritem.uar_reject,inneritem.project_name)\">\n                              <h2 class=\"list-title\"><span class=\"smspan\"> Category </span><br>\n                                {{inneritem.category_name}}\n                              </h2>\n                            </ion-col>\n                            <ion-col size=\"4\" (click)=\"detailsView(inneritem.uar_description,inneritem.uar_reject,inneritem.project_name)\">\n                              <h2 class=\"list-title\"><span class=\"smspan\">Sub category </span><br>\n                                {{inneritem.subcategory_name}}\n                              </h2>\n                            </ion-col> -->\n                             \n\n                              <ion-col size=\"5\" *ngIf=\"inneritem.status!='active' && inneritem.status!='payment_done' && inneritem.status!='pending'\" >\n                                <ion-button color=\"primary\" expand=\"block\" size=\"small\" fill=\"outline\" (click)=\"edit_expense(inneritem.uar_id)\">\n                                  <ion-icon slot=\"start\" name=\"create-outline\"></ion-icon>\n                                  Edit\n                                </ion-button>\n                             \n                    \n                              </ion-col>\n                              <ion-col size=\"5\" *ngIf=\"inneritem.status!='active' && inneritem.status!='payment_done' && inneritem.status!='pending'\" >\n                                <ion-button expand=\"block\" size=\"small\" fill=\"outline\" color=\"danger\" (click)=\"remove_expense(inneritem.uar_id)\">\n                                  <ion-icon slot=\"start\" name=\"trash-outline\"></ion-icon>\n                                  Delete\n                                </ion-button>\n                                \n                              \n                                </ion-col>\n                                <span *ngIf=\"inneritem.status!='active' && inneritem.status!='payment_done'\" style=\"    font-size: 10px;\n                                font-family: 'Inter Regular';\n                                font-weight: 900;\n                                color: #071662;\">Approval awaiting from {{inneritem.next_approved_text}}</span>\n                            \n                              </ion-row>\n                        </ion-label>\n                      </ion-col>\n                    \n                  \n                </ion-row>\n             \n                </div>\n\n                <div *ngIf=\"!depositData.length\">\n\n                  <ion-row>\n                    <ion-col size=\"12\">\n   <h2 class=\"list-title\" style=\"font-size: 22px;color: #af1313;text-align: center; font-weight: 600;\"> No record found \n                       \n                      </h2>\n                      </ion-col>\n                      </ion-row>\n                </div>\n             \n         \n         \n        \n    </ion-grid>\n    \n \n  \n\n</ion-content>");

/***/ }),

/***/ 50444:
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/component/advance/advance.component.html ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n\t<ion-item  (click)=\"popDismiss('home')\" class=\"item-class\">\n\t\t<ion-icon slot=\"start\" name=\"home-outline\" class=\"item-icon\"></ion-icon>Home\n\t</ion-item>\n\t<ion-item  (click)=\"popDismiss('advance-request-add')\" class=\"item-class\">\n\t\t<ion-icon slot=\"start\" name=\"add-circle-outline\" class=\"item-icon\"></ion-icon>Create Request\n\t</ion-item>\n\t\n\t \n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_advance_advance_module_ts.js.map